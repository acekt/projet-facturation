(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[620],{

/***/ 15927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ ChevronRight)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m9 18 6-6-6-6",
            key: "mthhwq"
        }
    ]
];
const ChevronRight = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("chevron-right", __iconNode);
 //# sourceMappingURL=chevron-right.js.map


/***/ }),

/***/ 25430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Building2)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M10 12h4",
            key: "a56b0p"
        }
    ],
    [
        "path",
        {
            d: "M10 8h4",
            key: "1sr2af"
        }
    ],
    [
        "path",
        {
            d: "M14 21v-3a2 2 0 0 0-4 0v3",
            key: "1rgiei"
        }
    ],
    [
        "path",
        {
            d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
            key: "secmi2"
        }
    ],
    [
        "path",
        {
            d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",
            key: "16ra0t"
        }
    ]
];
const Building2 = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("building-2", __iconNode);
 //# sourceMappingURL=building-2.js.map


/***/ }),

/***/ 25633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ FileText)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
            key: "1oefj6"
        }
    ],
    [
        "path",
        {
            d: "M14 2v5a1 1 0 0 0 1 1h5",
            key: "wfsgrz"
        }
    ],
    [
        "path",
        {
            d: "M10 9H8",
            key: "b1mrlr"
        }
    ],
    [
        "path",
        {
            d: "M16 13H8",
            key: "t4e002"
        }
    ],
    [
        "path",
        {
            d: "M16 17H8",
            key: "z1uh3a"
        }
    ]
];
const FileText = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("file-text", __iconNode);
 //# sourceMappingURL=file-text.js.map


/***/ }),

/***/ 26183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ MapPin)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
            key: "1r0f0z"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "10",
            r: "3",
            key: "ilqhr7"
        }
    ]
];
const MapPin = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("map-pin", __iconNode);
 //# sourceMappingURL=map-pin.js.map


/***/ }),

/***/ 45408:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ CircleCheck)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "m9 12 2 2 4-4",
            key: "dzmm74"
        }
    ]
];
const CircleCheck = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("circle-check", __iconNode);
 //# sourceMappingURL=circle-check.js.map


/***/ }),

/***/ 53694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Mail)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
            key: "132q7q"
        }
    ],
    [
        "rect",
        {
            x: "2",
            y: "4",
            width: "20",
            height: "16",
            rx: "2",
            key: "izxlao"
        }
    ]
];
const Mail = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("mail", __iconNode);
 //# sourceMappingURL=mail.js.map


/***/ }),

/***/ 55711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ UserCheck)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m16 11 2 2 4-4",
            key: "9rsbq5"
        }
    ],
    [
        "path",
        {
            d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
            key: "1yyitq"
        }
    ],
    [
        "circle",
        {
            cx: "9",
            cy: "7",
            r: "4",
            key: "nufk8"
        }
    ]
];
const UserCheck = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("user-check", __iconNode);
 //# sourceMappingURL=user-check.js.map


/***/ }),

/***/ 69294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ ChevronLeft)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m15 18-6-6 6-6",
            key: "1wnfg3"
        }
    ]
];
const ChevronLeft = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("chevron-left", __iconNode);
 //# sourceMappingURL=chevron-left.js.map


/***/ }),

/***/ 70177:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73912));


/***/ }),

/***/ 73912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SetupClient)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js
var action_client_wrapper = __webpack_require__(24372);
;// ./node_modules/next/dist/build/webpack/loaders/next-flight-server-reference-proxy-loader.js?id=40c879b4dc48aaf5fd1f87619776fad97d4bf8e196&name=setupApp!

const setupApp = /*#__PURE__*/(0,action_client_wrapper.createServerReference)("40c879b4dc48aaf5fd1f87619776fad97d4bf8e196", action_client_wrapper.callServer, undefined, action_client_wrapper.findSourceMapURL, "setupApp")
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(82222);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(34819);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(50277);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(81769);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(29094);
// EXTERNAL MODULE: ./lib/store.ts
var store = __webpack_require__(43922);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(73981);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/circle-check.js
var circle_check = __webpack_require__(45408);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/shield-check.js
var shield_check = __webpack_require__(78953);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/user-check.js
var user_check = __webpack_require__(55711);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/mail.js
var mail = __webpack_require__(53694);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/lock.js
var lock = __webpack_require__(16846);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/eye-off.js
var eye_off = __webpack_require__(99074);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/eye.js
var eye = __webpack_require__(81014);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/phone.js
var icons_phone = __webpack_require__(85463);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-right.js
var chevron_right = __webpack_require__(15927);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/building-2.js
var building_2 = __webpack_require__(25430);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/file-text.js
var file_text = __webpack_require__(25633);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/map-pin.js
var map_pin = __webpack_require__(26183);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-left.js
var chevron_left = __webpack_require__(69294);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/loader-circle.js
var loader_circle = __webpack_require__(42601);
;// ./app/setup/setup-client.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function SetupClient() {
    const router = (0,navigation.useRouter)();
    const [step, setStep] = react.useState(1);
    const [loading, setLoading] = react.useState(false);
    const [showPassword, setShowPassword] = react.useState(false);
    // Étape 1 : Admin
    const [name, setName] = react.useState('');
    const [email, setEmail] = react.useState('');
    const [password, setPassword] = react.useState('');
    const [phone, setPhone] = react.useState('');
    // Étape 2 : Entreprise
    const [companyName, setCompanyName] = react.useState('');
    const [nif, setNif] = react.useState('');
    const [rccm, setRccm] = react.useState('');
    const [address, setAddress] = react.useState('');
    const [companyPhone, setCompanyPhone] = react.useState('');
    const [companyEmail, setCompanyEmail] = react.useState('');
    const setUser = (0,store/* useStore */.P)((state)=>state.setUser);
    const handleNextStep = (e)=>{
        e.preventDefault();
        if (!name.trim()) {
            dist/* toast */.oR.error("Veuillez saisir votre nom complet");
            return;
        }
        if (!email.trim() || !email.includes('@')) {
            dist/* toast */.oR.error("Veuillez saisir une adresse email valide");
            return;
        }
        if (password.length < 6) {
            dist/* toast */.oR.error("Le mot de passe doit comporter au moins 6 caractères");
            return;
        }
        setStep(2);
    };
    const handleSubmit = async (e_0)=>{
        e_0.preventDefault();
        if (!companyName.trim()) {
            dist/* toast */.oR.error("Le nom de l'entreprise est requis");
            return;
        }
        setLoading(true);
        try {
            const res = await setupApp({
                name,
                email,
                password,
                phone,
                companyName,
                nif,
                rccm,
                address,
                companyPhone,
                companyEmail
            });
            if (res.success) {
                dist/* toast */.oR.success("Initialisation de Facturier réussie !");
                if (res.data?.user) {
                    setUser(res.data.user);
                }
                await new Promise((resolve)=>setTimeout(resolve, 300));
                router.push('/');
                router.refresh();
            } else {
                dist/* toast */.oR.error(res.error || "Erreur lors de l'initialisation");
            }
        } catch (err) {
            dist/* toast */.oR.error("Impossible de joindre le serveur local");
        } finally{
            setLoading(false);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "h-screen w-screen overflow-hidden flex bg-background transition-colors duration-300",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full h-full flex flex-col md:flex-row",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "hidden md:flex flex-col relative w-[45%] h-full bg-primary overflow-hidden p-10 justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative z-10",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-2 mb-12",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "relative w-12 h-12 bg-white rounded-lg shadow-md overflow-hidden",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                                src: "/logo.png",
                                                alt: "Logo Facturier",
                                                fill: true,
                                                className: "object-contain p-1"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                            className: "text-primary-foreground font-bold text-xl tracking-tight",
                                            children: "Facturier"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "mt-12 space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-primary-foreground/10 text-primary-foreground border border-primary-foreground/20",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                children: "Configuration Initiale"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                            className: "text-3xl font-bold text-primary-foreground leading-tight tracking-tight",
                                            children: "Initialisez votre espace s\xe9curis\xe9."
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            className: "text-primary-foreground/80 text-[15px] leading-relaxed max-w-md font-medium",
                                            children: "Configurez le compte administrateur principal ainsi que l'identit\xe9 fiscale de votre entreprise au Gabon."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "space-y-4 pt-12",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            onClick: ()=>setStep(1),
                                            className: `flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer ${step === 1 ? 'bg-primary-foreground/10 border-primary-foreground/20 shadow-sm' : 'bg-transparent border-transparent opacity-50 hover:opacity-100'}`,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                    className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${step === 1 ? 'bg-primary-foreground text-primary font-bold shadow-md' : 'bg-primary-foreground/20 text-primary-foreground font-bold'}`,
                                                    children: step === 2 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(circle_check/* default */.A, {
                                                        className: "w-5 h-5"
                                                    }) : '1'
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                            className: "text-sm font-bold text-primary-foreground",
                                                            children: "Compte Administrateur"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-xs text-primary-foreground/70 font-medium",
                                                            children: "Identifiants et acc\xe8s principaux"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            onClick: ()=>{
                                                if (name && email && password.length >= 6) setStep(2);
                                            },
                                            className: `flex items-center gap-4 p-4 rounded-2xl border transition-all ${step === 2 ? 'bg-primary-foreground/10 border-primary-foreground/20 shadow-sm' : 'bg-transparent border-transparent opacity-50 hover:opacity-100 cursor-pointer'}`,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                    className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-bold ${step === 2 ? 'bg-primary-foreground text-primary shadow-md' : 'bg-primary-foreground/20 text-primary-foreground'}`,
                                                    children: "2"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                            className: "text-sm font-bold text-primary-foreground",
                                                            children: "Profil de l'Entreprise"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-xs text-primary-foreground/70 font-medium",
                                                            children: "NIF, RCCM et coordonn\xe9es l\xe9gales"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center gap-2 text-xs text-primary-foreground/60 relative z-10 font-medium pt-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(shield_check/* default */.A, {
                                    className: "w-4 h-4 shrink-0"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Base SQLite locale 100% autonome et s\xe9curis\xe9e"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 right-0 w-[800px] h-[800px] bg-primary-foreground/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute bottom-0 left-0 w-[600px] h-[600px] bg-primary-foreground/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4 pointer-events-none"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex-1 flex flex-col justify-center items-center p-8 sm:p-12 md:p-16 relative bg-background overflow-y-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full max-w-[420px] space-y-10 my-auto",
                        children: step === 1 ? /* ========================================================= */ /* ÉTAPE 1 : ADMINISTRATEUR PRINCIPAL                        */ /* ========================================================= */ /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                            onSubmit: handleNextStep,
                            className: "space-y-8 animate-in fade-in slide-in-from-right-4 duration-300",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "text-center space-y-2 mb-8",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "flex justify-center mb-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                className: "w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center ring-4 ring-background shadow-sm",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(user_check/* default */.A, {
                                                    className: "w-8 h-8 text-primary"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                                            className: "text-2xl sm:text-3xl font-bold text-foreground tracking-tight",
                                            children: "Administrateur"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            className: "text-sm text-muted-foreground leading-relaxed font-medium",
                                            children: "Cr\xe9ez le compte qui aura le contr\xf4le total de Facturier."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "admin-name",
                                                    children: "Nom complet *"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                    id: "admin-name",
                                                    type: "text",
                                                    value: name,
                                                    onChange: (e_1)=>setName(e_1.target.value),
                                                    placeholder: "ex: Jean-Paul MBOUMBA",
                                                    className: "bg-secondary border-border text-foreground",
                                                    required: true
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "admin-email",
                                                    children: "Adresse email *"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(mail/* default */.A, {
                                                            className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                            id: "admin-email",
                                                            type: "email",
                                                            value: email,
                                                            onChange: (e_2)=>setEmail(e_2.target.value),
                                                            placeholder: "admin@facturier.ga",
                                                            className: "pl-10 bg-secondary border-border text-foreground",
                                                            required: true
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "admin-password",
                                                    children: "Mot de passe (min. 6 caract\xe8res) *"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(lock/* default */.A, {
                                                            className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                            id: "admin-password",
                                                            type: showPassword ? "text" : "password",
                                                            value: password,
                                                            onChange: (e_3)=>setPassword(e_3.target.value),
                                                            placeholder: "••••••••",
                                                            className: "pl-10 pr-10 bg-secondary border-border text-foreground",
                                                            required: true,
                                                            minLength: 6
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                                            type: "button",
                                                            onClick: ()=>setShowPassword(!showPassword),
                                                            className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors",
                                                            children: showPassword ? /*#__PURE__*/ (0,jsx_runtime.jsx)(eye_off/* default */.A, {
                                                                className: "w-4 h-4"
                                                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(eye/* default */.A, {
                                                                className: "w-4 h-4"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "admin-phone",
                                                    children: "T\xe9l\xe9phone (Optionnel)"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(icons_phone/* default */.A, {
                                                            className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                            id: "admin-phone",
                                                            type: "tel",
                                                            value: phone,
                                                            onChange: (e_4)=>setPhone(e_4.target.value),
                                                            placeholder: "+241 01 23 45 67",
                                                            className: "pl-10 bg-secondary border-border text-foreground"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "pt-2",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                        type: "submit",
                                        className: "w-full bg-primary hover:bg-primary/90 text-primary-foreground gap-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                children: "Continuer vers le Profil Entreprise"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_right/* default */.A, {
                                                className: "w-4 h-4"
                                            })
                                        ]
                                    })
                                })
                            ]
                        }) : /* ========================================================= */ /* ÉTAPE 2 : INFORMATIONS DE L'ENTREPRISE                    */ /* ========================================================= */ /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                            onSubmit: handleSubmit,
                            className: "space-y-8 animate-in fade-in slide-in-from-right-4 duration-300",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "text-center space-y-2 mb-8",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "flex justify-center mb-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                className: "w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center ring-4 ring-background shadow-sm",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(building_2/* default */.A, {
                                                    className: "w-8 h-8 text-primary"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                                            className: "text-2xl sm:text-3xl font-bold text-foreground tracking-tight",
                                            children: "Votre Entreprise"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            className: "text-sm text-muted-foreground leading-relaxed font-medium",
                                            children: "Ces informations figureront sur vos factures."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "company-name",
                                                    children: "Nom de l'entreprise *"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(building_2/* default */.A, {
                                                            className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                            id: "company-name",
                                                            type: "text",
                                                            value: companyName,
                                                            onChange: (e_5)=>setCompanyName(e_5.target.value),
                                                            placeholder: "ex: Facturier S.A.",
                                                            className: "pl-10 bg-secondary border-border text-foreground",
                                                            required: true
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            htmlFor: "company-nif",
                                                            children: "NIF"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(file_text/* default */.A, {
                                                                    className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    id: "company-nif",
                                                                    type: "text",
                                                                    value: nif,
                                                                    onChange: (e_6)=>setNif(e_6.target.value),
                                                                    placeholder: "NIF 123456",
                                                                    className: "pl-10 bg-secondary border-border text-foreground"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            htmlFor: "company-rccm",
                                                            children: "RCCM"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(file_text/* default */.A, {
                                                                    className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    id: "company-rccm",
                                                                    type: "text",
                                                                    value: rccm,
                                                                    onChange: (e_7)=>setRccm(e_7.target.value),
                                                                    placeholder: "GA-LBV-2026-B12",
                                                                    className: "pl-10 bg-secondary border-border text-foreground"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                    htmlFor: "company-address",
                                                    children: "Adresse"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(map_pin/* default */.A, {
                                                            className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                            id: "company-address",
                                                            type: "text",
                                                            value: address,
                                                            onChange: (e_8)=>setAddress(e_8.target.value),
                                                            placeholder: "Quartier Louis, Libreville",
                                                            className: "pl-10 bg-secondary border-border text-foreground"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            htmlFor: "company-phone",
                                                            children: "T\xe9l\xe9phone"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(icons_phone/* default */.A, {
                                                                    className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    id: "company-phone",
                                                                    type: "tel",
                                                                    value: companyPhone,
                                                                    onChange: (e_9)=>setCompanyPhone(e_9.target.value),
                                                                    placeholder: "+241 01 00 00 00",
                                                                    className: "pl-10 bg-secondary border-border text-foreground"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            htmlFor: "company-email",
                                                            children: "Email contact"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(mail/* default */.A, {
                                                                    className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    id: "company-email",
                                                                    type: "email",
                                                                    value: companyEmail,
                                                                    onChange: (e_10)=>setCompanyEmail(e_10.target.value),
                                                                    placeholder: "contact@facturier.ga",
                                                                    className: "pl-10 bg-secondary border-border text-foreground"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-3 pt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                            type: "button",
                                            variant: "outline",
                                            onClick: ()=>setStep(1),
                                            disabled: loading,
                                            className: "gap-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_left/* default */.A, {
                                                    className: "w-4 h-4"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    children: "Retour"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                            type: "submit",
                                            className: "flex-1 bg-primary hover:bg-primary/90 text-primary-foreground gap-2",
                                            disabled: loading,
                                            children: loading ? /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(loader_circle/* default */.A, {
                                                        className: "w-4 h-4 animate-spin mr-2"
                                                    }),
                                                    " Cr\xe9ation..."
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        children: "Terminer"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_right/* default */.A, {
                                                        className: "w-4 h-4"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 78953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ ShieldCheck)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
            key: "oel41y"
        }
    ],
    [
        "path",
        {
            d: "m9 12 2 2 4-4",
            key: "dzmm74"
        }
    ]
];
const ShieldCheck = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("shield-check", __iconNode);
 //# sourceMappingURL=shield-check.js.map


/***/ }),

/***/ 81014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Eye)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
            key: "1nclc0"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "3",
            key: "1v7zrd"
        }
    ]
];
const Eye = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("eye", __iconNode);
 //# sourceMappingURL=eye.js.map


/***/ }),

/***/ 81769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19749);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(86228);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(37570);
/* __next_internal_client_entry_do_not_use__ Label auto */ 




function Label(t0) {
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(8);
    let className;
    let props;
    if ($[0] !== t0) {
        ({ className, ...props } = t0);
        $[0] = t0;
        $[1] = className;
        $[2] = props;
    } else {
        className = $[1];
        props = $[2];
    }
    let t1;
    if ($[3] !== className) {
        t1 = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className);
        $[3] = className;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== props || $[6] !== t1) {
        t2 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .b, {
            "data-slot": "label",
            className: t1,
            ...props
        });
        $[5] = props;
        $[6] = t1;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    return t2;
}



/***/ }),

/***/ 85463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Phone)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
            key: "9njp5v"
        }
    ]
];
const Phone = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("phone", __iconNode);
 //# sourceMappingURL=phone.js.map


/***/ }),

/***/ 86228:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  b: () => (/* binding */ dist_Root)
});

// UNUSED EXPORTS: Label

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-dom/index.js
var react_dom = __webpack_require__(47650);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-slot/dist/index.mjs
var dist = __webpack_require__(36469);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
;// ./node_modules/@radix-ui/react-label/node_modules/@radix-ui/react-primitive/dist/index.mjs
// src/primitive.tsx




var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Slot = (0,dist/* createSlot */.TL)(`Primitive.${node}`);
  const Node = react.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot : node;
    if (typeof window !== "undefined") {
      window[Symbol.for("radix-ui")] = true;
    }
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node };
}, {});
function dispatchDiscreteCustomEvent(target, event) {
  if (target) ReactDOM.flushSync(() => target.dispatchEvent(event));
}
var Root = (/* unused pure expression or super */ null && (Primitive));

//# sourceMappingURL=index.mjs.map

;// ./node_modules/@radix-ui/react-label/dist/index.mjs
/* __next_internal_client_entry_do_not_use__ Label,Root auto */ // src/label.tsx



var NAME = "Label";
var Label = /*#__PURE__*/ react.forwardRef((props, forwardedRef)=>{
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(Primitive.label, {
        ...props,
        ref: forwardedRef,
        onMouseDown: (event)=>{
            const target = event.target;
            if (target.closest("button, input, select, textarea")) return;
            props.onMouseDown?.(event);
            if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
        }
    });
});
Label.displayName = NAME;
var dist_Root = Label;
 //# sourceMappingURL=index.mjs.map


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [878,804,366,680,441,826,358], () => (__webpack_exec__(70177)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);