"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[680],{

/***/ 34819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19749);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(37570);




function Input(t0) {
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(10);
    let className;
    let props;
    let type;
    if ($[0] !== t0) {
        ({ className, type, ...props } = t0);
        $[0] = t0;
        $[1] = className;
        $[2] = props;
        $[3] = type;
    } else {
        className = $[1];
        props = $[2];
        type = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1 || $[8] !== type) {
        t2 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
            type: type,
            "data-slot": "input",
            className: t1,
            ...props
        });
        $[6] = props;
        $[7] = t1;
        $[8] = type;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    return t2;
}



/***/ }),

/***/ 37570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Yq: () => (/* binding */ formatDate),
/* harmony export */   cn: () => (/* binding */ cn),
/* harmony export */   vv: () => (/* binding */ formatCurrency)
/* harmony export */ });
/* unused harmony export formatShortCurrency */
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89279);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71563);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_0__/* .twMerge */ .QP)((0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)(inputs));
}
function formatCurrency(value) {
    return new Intl.NumberFormat("fr-FR", {
        style: "decimal",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(Math.round(value)).replace(/\u00a0/g, " ") + " FCFA";
}
function formatShortCurrency(value) {
    return formatCurrency(value);
}
function formatDate(dateString) {
    if (!dateString) return '';
    // Si c'est un format ISO strict YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateString.trim())) {
        const [year, month, day] = dateString.trim().split('-');
        return `${day}/${month}/${year}`;
    }
    // Fallback pour les timestamps complets (Date)
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat('fr-FR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    }).format(date);
}


/***/ }),

/***/ 43922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ useStore)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49723);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13229);
/* __next_internal_client_entry_do_not_use__ useStore auto */ 

const ADMIN_PERMISSIONS = {
    canViewDashboard: true,
    canViewSettings: true,
    canViewAuditLog: true,
    canViewUsers: true,
    canManageUsers: true,
    canViewCustomers: false,
    canViewQuotes: false,
    canCreateQuote: false,
    canViewInvoices: false,
    canViewServices: false,
    canResetPassword: true,
    canDeactivateUser: true
};
const USER_PERMISSIONS = {
    canViewDashboard: true,
    canViewSettings: true,
    canViewAuditLog: false,
    canViewUsers: false,
    canManageUsers: false,
    canViewCustomers: true,
    canViewQuotes: true,
    canCreateQuote: true,
    canViewInvoices: true,
    canViewServices: true,
    canResetPassword: false,
    canDeactivateUser: false
};
// ============================================================================
// Default Settings — fallback before API response
// ============================================================================
const DEFAULT_SETTINGS = {
    id: 1,
    companyName: "Global Maintenance",
    legalForm: "SARL",
    nif: "XXXXXXXXXX",
    rccm: "GA-LBV-XX-XXXX-XXXX",
    address: "123 Boulevard Triomphal, Libreville, Gabon",
    email: "facturation@globalm.ga",
    phone: "+241 01 76 XX XX",
    bankName: "BGFI Bank",
    bankAgency: "Libreville",
    accountNumber: "XXXXXXXXXX",
    swiftCode: "BGFIGAXX",
    iban: "GAXX XXXX XXXX XXXX XXXX",
    tvaRate: 18,
    tpsRate: 9.5,
    cssRate: 1,
    sessionTimeout: 30,
    invoicePrefix: "FAC",
    quotePrefix: "DEV",
    companyCode: "GM",
    mentionsLegales: null,
    logo: null
};
// ============================================================================
// Store
// ============================================================================
const useStore = (0,zustand__WEBPACK_IMPORTED_MODULE_0__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_1__/* .persist */ .Zr)((set)=>({
        user: null,
        permissions: null,
        isAuthenticated: false,
        isDataLoaded: false,
        clients: [],
        quotes: [],
        invoices: [],
        services: [],
        payments: [],
        creditNotes: [],
        settings: DEFAULT_SETTINGS,
        users: [],
        dashboardMetrics: null,
        viewFormat: {
            quotes: "table",
            invoices: "table",
            clients: "block",
            services: "block",
            creditNotes: "horizontal"
        },
        invoiceDraft: {
            selectedClient: null,
            items: [
                {
                    id: "1",
                    description: "",
                    quantity: 1,
                    unitPrice: 0,
                    total: 0
                }
            ],
            invoiceDate: new Date().toISOString().split("T")[0],
            discount: 0,
            notes: ""
        },
        quoteDraft: {
            selectedClient: null,
            items: [
                {
                    id: "1",
                    description: "",
                    quantity: 1,
                    unitPrice: 0,
                    total: 0
                }
            ],
            quoteDate: new Date().toISOString().split("T")[0],
            discount: 0,
            notes: "",
            status: "EN_ATTENTE"
        },
        /**
       * @function setIsDataLoaded
       * @description Flag controlling the visibility of the loading spinner during DataSync hydration.
       * @param {boolean} isDataLoaded - True when background API calls are fully complete.
       */ setIsDataLoaded: (isDataLoaded)=>set({
                isDataLoaded
            }),
        /**
       * @function setDashboardMetrics
       * @description Updates global dashboard analytical metrics.
       * @param {DashboardMetricsResponse | null} dashboardMetrics - The analytics dataset.
       */ setDashboardMetrics: (dashboardMetrics)=>set({
                dashboardMetrics
            }),
        /**
       * @function setUser
       * @description Updates the connected user and maps their RBAC permissions.
       * @param {User | null} user - The authenticated user or null on logout.
       */ setUser: (user)=>{
            const permissions = user ? user.role === "admin" ? ADMIN_PERMISSIONS : USER_PERMISSIONS : null;
            set({
                user,
                permissions,
                isAuthenticated: !!user
            });
        },
        /**
       * @function setClients
       * @description Écrase l'intégralité de la liste des clients (utilisé lors du chargement initial via DataSync).
       * @param {Client[]} clients - Tableau complet des clients actifs.
       */ setClients: (clients)=>set({
                clients
            }),
        // Atomic client mutations: each reads fresh state via set(state => ...) — no stale closure.
        /**
       * @function addClient
       * @description Ajoute un nouveau client de manière strictement immuable au store.
       * @param {Client} client - L'objet client à ajouter.
       */ addClient: (client)=>set((state)=>({
                    clients: [
                        ...state.clients,
                        client
                    ]
                })),
        /**
       * @function removeClient
       * @description Supprime un client existant en filtrant par ID de façon immuable.
       * @param {string} id - L'identifiant unique du client.
       */ removeClient: (id)=>set((state)=>({
                    clients: state.clients.filter((c)=>c.id !== id)
                })),
        /**
       * @function updateClient
       * @description Met à jour partiellement les informations d'un client de manière immuable.
       * @param {string} id - L'identifiant du client.
       * @param {Partial<Client>} data - Les données à fusionner.
       */ updateClient: (id, data)=>set((state)=>({
                    clients: state.clients.map((c)=>c.id === id ? {
                            ...c,
                            ...data
                        } : c)
                })),
        /**
       * @function replaceClient
       * @description Remplace une entrée client (utile pour réconcilier les ID temporaires de création locale avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire du client.
       * @param {Client} confirmed - L'objet client confirmé par le serveur.
       */ replaceClient: (tempId, confirmed)=>set((state)=>({
                    clients: state.clients.map((c)=>c.id === tempId ? confirmed : c)
                })),
        /**
       * @function setQuotes
       * @description Overwrites the entire quotes list (used initially by DataSync).
       * @param {Quote[]} quotes - Full array of quotes.
       */ setQuotes: (quotes)=>set({
                quotes
            }),
        /**
       * @function addQuote
       * @description Ajoute un nouveau devis de manière immuable au store.
       * @param {Quote} quote - L'objet devis à ajouter.
       */ addQuote: (quote)=>set((state)=>({
                    quotes: [
                        quote,
                        ...state.quotes
                    ]
                })),
        /**
       * @function removeQuote
       * @description Supprime un devis existant en filtrant par ID.
       * @param {string} id - L'identifiant unique du devis.
       */ removeQuote: (id)=>set((state)=>({
                    quotes: state.quotes.filter((q)=>q.id !== id)
                })),
        /**
       * @function updateQuote
       * @description Met à jour partiellement les informations d'un devis.
       * @param {string} id - L'identifiant du devis.
       * @param {Partial<Quote>} data - Les données à mettre à jour.
       */ updateQuote: (id, data)=>set((state)=>({
                    quotes: state.quotes.map((q)=>q.id === id ? {
                            ...q,
                            ...data
                        } : q)
                })),
        /**
       * @function replaceQuote
       * @description Remplace une entrée devis (utile pour réconcilier les ID temporaires avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire du devis.
       * @param {Quote} confirmed - L'objet devis confirmé par le serveur.
       */ replaceQuote: (tempId, confirmed)=>set((state)=>({
                    quotes: state.quotes.map((q)=>q.id === tempId ? confirmed : q)
                })),
        /**
       * @function setInvoices
       * @description Overwrites the entire invoices list (used initially by DataSync).
       * @param {Invoice[]} invoices - Full array of invoices.
       */ setInvoices: (invoices)=>set({
                invoices
            }),
        /**
       * @function addInvoice
       * @description Ajoute une nouvelle facture de manière immuable au store.
       * @param {Invoice} invoice - L'objet facture à ajouter.
       */ addInvoice: (invoice)=>set((state)=>({
                    invoices: [
                        invoice,
                        ...state.invoices
                    ]
                })),
        /**
       * @function removeInvoice
       * @description Supprime une facture existante en filtrant par ID.
       * @param {string} id - L'identifiant unique de la facture.
       */ removeInvoice: (id)=>set((state)=>({
                    invoices: state.invoices.filter((i)=>i.id !== id)
                })),
        /**
       * @function updateInvoice
       * @description Met à jour partiellement les informations d'une facture.
       * @param {string} id - L'identifiant de la facture.
       * @param {Partial<Invoice>} data - Les données à mettre à jour.
       */ updateInvoice: (id, data)=>set((state)=>({
                    invoices: state.invoices.map((i)=>i.id === id ? {
                            ...i,
                            ...data
                        } : i)
                })),
        /**
       * @function replaceInvoice
       * @description Remplace une entrée facture (utile pour réconcilier les ID temporaires avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire de la facture.
       * @param {Invoice} confirmed - L'objet facture confirmé par le serveur.
       */ replaceInvoice: (tempId, confirmed)=>set((state)=>({
                    invoices: state.invoices.map((i)=>i.id === tempId ? confirmed : i)
                })),
        /**
       * @function setServices
       * @description Overwrites the entire services list (used initially by DataSync).
       * @param {Service[]} services - Full array of active services.
       */ setServices: (services)=>set({
                services
            }),
        // Atomic service mutations: same pattern as clients.
        /**
       * @function addService
       * @description Ajoute un nouveau service de manière immuable au store.
       * @param {Service} service - L'objet service à ajouter.
       */ addService: (service)=>set((state)=>({
                    services: [
                        ...state.services,
                        service
                    ]
                })),
        /**
       * @function removeService
       * @description Supprime un service existant en filtrant par ID.
       * @param {string} id - L'identifiant unique du service.
       */ removeService: (id)=>set((state)=>({
                    services: state.services.filter((s)=>s.id !== id)
                })),
        /**
       * @function updateService
       * @description Met à jour partiellement les informations d'un service.
       * @param {string} id - L'identifiant du service.
       * @param {Partial<Service>} data - Les données à mettre à jour.
       */ updateService: (id, data)=>set((state)=>({
                    services: state.services.map((s)=>s.id === id ? {
                            ...s,
                            ...data
                        } : s)
                })),
        /**
       * @function replaceService
       * @description Remplace une entrée service (utile pour réconcilier les ID temporaires avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire du service.
       * @param {Service} confirmed - L'objet service confirmé par le serveur.
       */ replaceService: (tempId, confirmed)=>set((state)=>({
                    services: state.services.map((s)=>s.id === tempId ? confirmed : s)
                })),
        /**
       * @function setPayments
       * @description Overwrites the entire payments list (used initially by DataSync).
       * @param {Payment[]} payments - Full array of payments.
       */ setPayments: (payments)=>set({
                payments
            }),
        /**
       * @function addPayment
       * @description Ajoute un nouveau paiement de manière immuable au store.
       * @param {Payment} payment - L'objet paiement à ajouter.
       */ addPayment: (payment)=>set((state)=>({
                    payments: [
                        payment,
                        ...state.payments
                    ]
                })),
        /**
       * @function removePayment
       * @description Supprime un paiement existant en filtrant par ID.
       * @param {string} id - L'identifiant unique du paiement.
       */ removePayment: (id)=>set((state)=>({
                    payments: state.payments.filter((p)=>p.id !== id)
                })),
        /**
       * @function updatePayment
       * @description Met à jour partiellement les informations d'un paiement.
       * @param {string} id - L'identifiant du paiement.
       * @param {Partial<Payment>} data - Les données à mettre à jour.
       */ updatePayment: (id, data)=>set((state)=>({
                    payments: state.payments.map((p)=>p.id === id ? {
                            ...p,
                            ...data
                        } : p)
                })),
        /**
       * @function replacePayment
       * @description Remplace une entrée paiement (utile pour réconcilier les ID temporaires avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire du paiement.
       * @param {Payment} confirmed - L'objet paiement confirmé par le serveur.
       */ replacePayment: (tempId, confirmed)=>set((state)=>({
                    payments: state.payments.map((p)=>p.id === tempId ? confirmed : p)
                })),
        /**
       * @function setCreditNotes
       * @description Overwrites the entire credit notes list (used initially by DataSync).
       * @param {CreditNote[]} creditNotes - Full array of credit notes.
       */ setCreditNotes: (creditNotes)=>set({
                creditNotes
            }),
        /**
       * @function addCreditNote
       * @description Ajoute un nouvel avoir de manière immuable au store.
       * @param {CreditNote} creditNote - L'objet avoir à ajouter.
       */ addCreditNote: (creditNote)=>set((state)=>({
                    creditNotes: [
                        creditNote,
                        ...state.creditNotes
                    ]
                })),
        /**
       * @function removeCreditNote
       * @description Supprime un avoir existant en filtrant par ID.
       * @param {string} id - L'identifiant unique de l'avoir.
       */ removeCreditNote: (id)=>set((state)=>({
                    creditNotes: state.creditNotes.filter((c)=>c.id !== id)
                })),
        /**
       * @function updateCreditNote
       * @description Met à jour partiellement les informations d'un avoir.
       * @param {string} id - L'identifiant de l'avoir.
       * @param {Partial<CreditNote>} data - Les données à mettre à jour.
       */ updateCreditNote: (id, data)=>set((state)=>({
                    creditNotes: state.creditNotes.map((c)=>c.id === id ? {
                            ...c,
                            ...data
                        } : c)
                })),
        /**
       * @function replaceCreditNote
       * @description Remplace une entrée avoir (utile pour réconcilier les ID temporaires avec les ID confirmés par le serveur).
       * @param {string} tempId - L'ID temporaire de l'avoir.
       * @param {CreditNote} confirmed - L'objet avoir confirmé par le serveur.
       */ replaceCreditNote: (tempId, confirmed)=>set((state)=>({
                    creditNotes: state.creditNotes.map((c)=>c.id === tempId ? confirmed : c)
                })),
        /**
       * @function setSettings
       * @description Replaces all global settings with fresh API data.
       * @param {Settings} settings - The complete settings object.
       */ setSettings: (settings)=>set({
                settings
            }),
        /**
       * @function updateSettings
       * @description Partially updates global configuration settings immutably.
       * @param {Partial<Settings>} updates - Changed setting key-value pairs.
       */ updateSettings: (updates)=>set((state)=>({
                    settings: {
                        ...state.settings,
                        ...updates
                    }
                })),
        /**
       * @function setViewFormat
       * @description Toggles display layout preference (table/block/etc.) for a specific view.
       * @param {keyof ViewFormat} page - The view to format (e.g. 'quotes', 'invoices').
       * @param {ViewFormat[keyof ViewFormat]} format - The layout type.
       */ setViewFormat: (page, format)=>set((state)=>({
                    viewFormat: {
                        ...state.viewFormat,
                        [page]: format
                    }
                })),
        /**
       * @function setUsers
       * @description Overwrites the user registry (admin only).
       * @param {UserResponse[]} users - The full list of system users.
       */ setUsers: (users)=>set({
                users
            }),
        /**
       * @function addUser
       * @description Adds a new user account immutably to the store.
       * @param {UserResponse} user - The new user object.
       */ addUser: (user)=>set((state)=>({
                    users: [
                        ...state.users,
                        user
                    ]
                })),
        /**
       * @function updateUser
       * @description Modifies specific user properties immutably.
       * @param {string} id - Target user ID.
       * @param {Partial<UserResponse>} updates - The data to merge.
       */ updateUser: (id, updates)=>set((state)=>({
                    users: state.users.map((u)=>u.id === id ? {
                            ...u,
                            ...updates
                        } : u)
                })),
        /**
       * @function removeUser
       * @description Performs a soft delete by setting is_active to 0 immutably.
       * @param {string} id - The user ID to deactivate.
       */ removeUser: (id)=>set((state)=>({
                    users: state.users.map((u)=>u.id === id ? {
                            ...u,
                            is_active: 0,
                            deletedAt: new Date().toISOString()
                        } : u)
                })),
        /**
       * @function setInvoiceDraft
       * @description Updates in-progress unsaved invoice modifications.
       * @param {Partial<InvoiceDraft>} draft - Partial draft state to merge.
       */ setInvoiceDraft: (draft)=>set((state)=>({
                    invoiceDraft: {
                        ...state.invoiceDraft,
                        ...draft
                    }
                })),
        /**
       * @function clearInvoiceDraft
       * @description Resets the invoice editor to a blank baseline applying legal mentions.
       */ clearInvoiceDraft: ()=>set((state)=>({
                    invoiceDraft: {
                        selectedClient: null,
                        items: [
                            {
                                id: "1",
                                description: "",
                                quantity: 1,
                                unitPrice: 0,
                                total: 0
                            }
                        ],
                        invoiceDate: new Date().toISOString().split("T")[0],
                        discount: 0,
                        notes: state.settings.mentionsLegales || "",
                        subject: ""
                    }
                })),
        /**
       * @function setQuoteDraft
       * @description Updates in-progress unsaved quote modifications.
       * @param {Partial<QuoteDraft>} draft - Partial draft state to merge.
       */ setQuoteDraft: (draft)=>set((state)=>({
                    quoteDraft: {
                        ...state.quoteDraft,
                        ...draft
                    }
                })),
        /**
       * @function clearQuoteDraft
       * @description Resets the quote editor with standard defaults (30 days validity).
       */ clearQuoteDraft: ()=>{
            const today = new Date();
            const next30Days = new Date(today);
            next30Days.setDate(today.getDate() + 30);
            return set((state)=>({
                    quoteDraft: {
                        selectedClient: null,
                        items: [
                            {
                                id: "1",
                                description: "",
                                quantity: 1,
                                unitPrice: 0,
                                total: 0
                            }
                        ],
                        quoteDate: today.toISOString().split("T")[0],
                        discount: 0,
                        notes: state.settings.mentionsLegales || "",
                        subject: "",
                        validUntil: next30Days.toISOString().split("T")[0],
                        status: "EN_ATTENTE"
                    }
                }));
        }
    }), {
    name: 'facturier-storage',
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_1__/* .createJSONStorage */ .KU)(()=>sessionStorage),
    // OPTIMISATION : Ne pas persister `settings` pour forcer le chargement frais via SQLite (DataSync)
    partialize: (state)=>({
            user: state.user,
            permissions: state.permissions,
            isAuthenticated: state.isAuthenticated,
            viewFormat: state.viewFormat
        })
}));


/***/ }),

/***/ 50277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button),
/* harmony export */   r: () => (/* binding */ buttonVariants)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19749);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(36469);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6267);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(37570);






const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary-hover',
            success: 'bg-accent text-accent-foreground hover:bg-accent-hover',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-primary-light hover:text-primary dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-primary-light hover:text-primary dark:hover:bg-primary/20',
            link: 'text-primary underline-offset-4 hover:underline',
            'primary-shadow': 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button(t0) {
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(14);
    let className;
    let props;
    let size;
    let t1;
    let variant;
    if ($[0] !== t0) {
        ({ className, variant, size, asChild: t1, ...props } = t0);
        $[0] = t0;
        $[1] = className;
        $[2] = props;
        $[3] = size;
        $[4] = t1;
        $[5] = variant;
    } else {
        className = $[1];
        props = $[2];
        size = $[3];
        t1 = $[4];
        variant = $[5];
    }
    const asChild = t1 === undefined ? false : t1;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    let t2;
    if ($[6] !== className || $[7] !== size || $[8] !== variant) {
        t2 = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)(buttonVariants({
            variant,
            size,
            className
        }));
        $[6] = className;
        $[7] = size;
        $[8] = variant;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    let t3;
    if ($[10] !== Comp || $[11] !== props || $[12] !== t2) {
        t3 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
            "data-slot": "button",
            className: t2,
            ...props
        });
        $[10] = Comp;
        $[11] = props;
        $[12] = t2;
        $[13] = t3;
    } else {
        t3 = $[13];
    }
    return t3;
}



/***/ })

}]);