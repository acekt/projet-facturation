"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[928],{

/***/ 70928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PDFDocument: () => (/* binding */ PDFDocument)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19749);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68269);
/* __next_internal_client_entry_do_not_use__ PDFDocument auto */ 



// Register a clean font if possible, otherwise use standard fonts
// Font.register({ family: 'Helvetica', ... });
const styles = _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .StyleSheet */ .vv.create({
    page: {
        padding: 40,
        fontSize: 10,
        fontFamily: 'Helvetica',
        color: '#333',
        backgroundColor: '#fff'
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 40,
        paddingBottom: 15
    },
    logoSection: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10
    },
    logo: {
        width: 60,
        height: 60,
        objectFit: 'contain'
    },
    companyName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1a365d',
        textTransform: 'uppercase'
    },
    companyDetails: {
        fontSize: 8,
        color: '#666',
        marginTop: 2
    },
    docTypeSection: {
        textAlign: 'right'
    },
    docHeaderContainer: {
        borderWidth: 1,
        borderColor: '#000',
        borderRadius: 8,
        padding: 8,
        width: 200,
        alignSelf: 'flex-end',
        marginBottom: 10
    },
    docType: {
        fontSize: 18,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        textAlign: 'center'
    },
    docNumber: {
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center'
    },
    dateSection: {
        marginTop: 10,
        fontSize: 9
    },
    infoGrid: {
        flexDirection: 'row',
        gap: 20,
        marginBottom: 30
    },
    infoBox: {
        flex: 1,
        padding: 10,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#eee'
    },
    infoBoxGray: {
        flex: 1,
        padding: 10,
        borderRadius: 4,
        backgroundColor: '#f9fafb',
        borderWidth: 1,
        borderColor: '#eee'
    },
    infoTitle: {
        fontSize: 7,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        color: '#9ca3af',
        borderBottomWidth: 1,
        borderBottomColor: '#eee',
        paddingBottom: 2,
        marginBottom: 5
    },
    infoText: {
        fontSize: 10,
        fontWeight: 'bold',
        marginBottom: 2
    },
    infoSubtext: {
        fontSize: 8,
        color: '#4b5563'
    },
    table: {
        display: 'flex',
        width: 'auto',
        marginBottom: 30
    },
    tableHeader: {
        flexDirection: 'row',
        backgroundColor: '#E6F0FF',
        borderWidth: 1,
        borderColor: '#000'
    },
    tableRow: {
        flexDirection: 'row',
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderBottomWidth: 1,
        borderColor: '#000',
        minHeight: 30,
        alignItems: 'center'
    },
    colDescription: {
        width: '55%',
        padding: 5
    },
    colQty: {
        width: '10%',
        textAlign: 'right',
        padding: 5
    },
    colPrice: {
        width: '15%',
        textAlign: 'right',
        padding: 5
    },
    colTotal: {
        width: '20%',
        textAlign: 'right',
        padding: 5
    },
    tableHeaderText: {
        fontSize: 8,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        color: '#000'
    },
    totalsSection: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 30
    },
    totalsContainer: {
        width: '100%',
        flexDirection: 'row',
        borderWidth: 1,
        borderColor: '#000'
    },
    totalCol: {
        flex: 1,
        borderRightWidth: 1,
        borderColor: '#000',
        padding: 4,
        alignItems: 'center'
    },
    totalColLast: {
        flex: 1,
        padding: 4,
        alignItems: 'center'
    },
    totalLabel: {
        fontSize: 8,
        fontWeight: 'bold',
        marginBottom: 2
    },
    totalVal: {
        fontSize: 9,
        fontWeight: 'bold'
    },
    totalRowBold: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 4,
        paddingHorizontal: 8,
        backgroundColor: '#f9fafb',
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: '#eee',
        marginVertical: 2
    },
    totalFinal: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 10,
        paddingHorizontal: 8,
        backgroundColor: '#003399',
        color: '#fff',
        borderRadius: 4,
        marginTop: 5
    },
    totalFinalText: {
        fontSize: 12,
        fontWeight: 'bold'
    },
    bankSection: {
        padding: 10,
        borderWidth: 1,
        borderColor: '#eee',
        borderStyle: 'dashed',
        borderRadius: 8,
        marginBottom: 40
    },
    bankTitle: {
        fontSize: 7,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        color: '#9ca3af',
        marginBottom: 5
    },
    bankGrid: {
        flexDirection: 'row',
        gap: 20
    },
    footer: {
        marginTop: 'auto',
        borderTopWidth: 1,
        borderTopColor: '#f3f4f6',
        paddingTop: 15
    },
    validationSection: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 15
    },
    hashText: {
        fontFamily: 'Courier',
        fontSize: 7,
        color: '#9ca3af',
        marginTop: 2
    },
    badge: {
        fontSize: 7,
        fontWeight: 'bold',
        paddingHorizontal: 6,
        paddingVertical: 2,
        borderWidth: 1,
        borderColor: '#00339933',
        backgroundColor: '#00339908',
        color: '#003399',
        borderRadius: 2
    },
    bottomCenter: {
        textAlign: 'center',
        fontSize: 8,
        color: '#9ca3af'
    }
});
function formatCurrencyPDF(amount) {
    return new Intl.NumberFormat('fr-FR', {
        style: 'decimal',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(Math.round(amount)).replace(/\u00a0/g, ' ') + ' FCFA';
}
function generateHash(doc, type) {
    const inputStr = `${type}-${doc.number || ''}-${doc.date || ''}-${doc.total || 0}`;
    let hash = 0;
    for(let i = 0; i < inputStr.length; i++){
        hash = (hash << 5) - hash + inputStr.charCodeAt(i);
        hash = hash & hash;
    }
    const hexHash = Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
    return `DGI-VAL-${hexHash.substring(0, 4)}-${hexHash.substring(4, 8)}-${(Math.round(doc.total) % 997).toString().padStart(3, '0')}`;
}
const PDFDocument = (t0)=>{
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(141);
    const { document, type, settings } = t0;
    generateHash(document, type);
    const docTypeLabel = type === "devis" ? "DEVIS" : type === "facture" ? "FACTURE" : "AVOIR";
    let t1;
    if ($[0] !== type) {
        t1 = type.toUpperCase();
        $[0] = type;
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const t2 = `${t1}_${document.number}`;
    let t3;
    if ($[2] !== settings.logo) {
        t3 = settings.logo ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Image */ ._V, {
            src: settings.logo,
            style: styles.logo
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: [
                styles.logo,
                {
                    backgroundColor: "#eee",
                    borderRadius: 10
                }
            ]
        });
        $[2] = settings.logo;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== settings.companyName) {
        t4 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: styles.companyName,
                children: settings.companyName
            })
        });
        $[4] = settings.companyName;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== t3 || $[7] !== t4) {
        t5 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.logoSection,
            children: [
                t3,
                t4
            ]
        });
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            fontSize: 10,
            marginBottom: 20
        };
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== document.date) {
        t7 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t6,
            children: [
                "Moanda, le ",
                document.date
            ]
        });
        $[10] = document.date;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== docTypeLabel || $[13] !== document.number) {
        t8 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.docHeaderContainer,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: styles.docType,
                children: [
                    docTypeLabel,
                    ": N\xb0",
                    document.number
                ]
            })
        });
        $[12] = docTypeLabel;
        $[13] = document.number;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== t7 || $[16] !== t8) {
        t9 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.docTypeSection,
            children: [
                t7,
                t8
            ]
        });
        $[15] = t7;
        $[16] = t8;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[18] !== t5 || $[19] !== t9) {
        t10 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.header,
            children: [
                t5,
                t9
            ]
        });
        $[18] = t5;
        $[19] = t9;
        $[20] = t10;
    } else {
        t10 = $[20];
    }
    let t11;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            marginBottom: 30,
            fontSize: 10
        };
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            fontWeight: "bold"
        };
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== document.clientName) {
        t13 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t12,
            children: [
                "Client: ",
                document.clientName
            ]
        });
        $[23] = document.clientName;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    const t14 = ("notes" in document ? document.notes : null) || "Prestations de services";
    let t15;
    if ($[25] !== t14) {
        t15 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "Objet: ",
                t14
            ]
        });
        $[25] = t14;
        $[26] = t15;
    } else {
        t15 = $[26];
    }
    let t16;
    let t17;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: "NIF:"
        });
        t17 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: "BC:"
        });
        $[27] = t16;
        $[28] = t17;
    } else {
        t16 = $[27];
        t17 = $[28];
    }
    let t18;
    if ($[29] !== t13 || $[30] !== t15) {
        t18 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: t11,
            children: [
                t13,
                t15,
                t16,
                t17
            ]
        });
        $[29] = t13;
        $[30] = t15;
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.colDescription,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: styles.tableHeaderText,
                children: "D\xe9signation"
            })
        });
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    let t20;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.colQty,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: styles.tableHeaderText,
                children: "Qt\xe9"
            })
        });
        $[33] = t20;
    } else {
        t20 = $[33];
    }
    let t21;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.colPrice,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: styles.tableHeaderText,
                children: "P.U (HT)"
            })
        });
        $[34] = t21;
    } else {
        t21 = $[34];
    }
    let t22;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.tableHeader,
            children: [
                t19,
                t20,
                t21,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                    style: styles.colTotal,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                        style: styles.tableHeaderText,
                        children: "Total (HT)"
                    })
                })
            ]
        });
        $[35] = t22;
    } else {
        t22 = $[35];
    }
    let t23;
    if ($[36] !== document.items) {
        t23 = document.items.map(_temp);
        $[36] = document.items;
        $[37] = t23;
    } else {
        t23 = $[37];
    }
    let t24;
    if ($[38] !== t23) {
        t24 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.table,
            children: [
                t22,
                t23
            ]
        });
        $[38] = t23;
        $[39] = t24;
    } else {
        t24 = $[39];
    }
    let t25;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: "Brut HT"
        });
        $[40] = t25;
    } else {
        t25 = $[40];
    }
    let t26;
    if ($[41] !== document.subtotal) {
        t26 = formatCurrencyPDF(document.subtotal);
        $[41] = document.subtotal;
        $[42] = t26;
    } else {
        t26 = $[42];
    }
    let t27;
    if ($[43] !== t26) {
        t27 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalCol,
            children: [
                t25,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: styles.totalVal,
                    children: t26
                })
            ]
        });
        $[43] = t26;
        $[44] = t27;
    } else {
        t27 = $[44];
    }
    let t28;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: "Remise"
        });
        $[45] = t28;
    } else {
        t28 = $[45];
    }
    const t29 = "discount" in document ? document.discount : 0;
    let t30;
    if ($[46] !== t29) {
        t30 = formatCurrencyPDF(t29);
        $[46] = t29;
        $[47] = t30;
    } else {
        t30 = $[47];
    }
    let t31;
    if ($[48] !== t30) {
        t31 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalCol,
            children: [
                t28,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: styles.totalVal,
                    children: t30
                })
            ]
        });
        $[48] = t30;
        $[49] = t31;
    } else {
        t31 = $[49];
    }
    let t32;
    if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: "Net HT"
        });
        $[50] = t32;
    } else {
        t32 = $[50];
    }
    const t33 = document.taxBase - document.cssAmount;
    let t34;
    if ($[51] !== t33) {
        t34 = formatCurrencyPDF(t33);
        $[51] = t33;
        $[52] = t34;
    } else {
        t34 = $[52];
    }
    let t35;
    if ($[53] !== t34) {
        t35 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalCol,
            children: [
                t32,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: styles.totalVal,
                    children: t34
                })
            ]
        });
        $[53] = t34;
        $[54] = t35;
    } else {
        t35 = $[54];
    }
    let t36;
    if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: "CSS"
        });
        $[55] = t36;
    } else {
        t36 = $[55];
    }
    let t37;
    if ($[56] !== document.cssAmount) {
        t37 = formatCurrencyPDF(document.cssAmount);
        $[56] = document.cssAmount;
        $[57] = t37;
    } else {
        t37 = $[57];
    }
    let t38;
    if ($[58] !== t37) {
        t38 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalCol,
            children: [
                t36,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: styles.totalVal,
                    children: t37
                })
            ]
        });
        $[58] = t37;
        $[59] = t38;
    } else {
        t38 = $[59];
    }
    let t39;
    if ($[60] !== settings.tvaRate) {
        t39 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: [
                "TVA ",
                settings.tvaRate,
                "%"
            ]
        });
        $[60] = settings.tvaRate;
        $[61] = t39;
    } else {
        t39 = $[61];
    }
    let t40;
    if ($[62] !== document.tvaAmount) {
        t40 = formatCurrencyPDF(document.tvaAmount);
        $[62] = document.tvaAmount;
        $[63] = t40;
    } else {
        t40 = $[63];
    }
    let t41;
    if ($[64] !== t40) {
        t41 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalVal,
            children: t40
        });
        $[64] = t40;
        $[65] = t41;
    } else {
        t41 = $[65];
    }
    let t42;
    if ($[66] !== t39 || $[67] !== t41) {
        t42 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalCol,
            children: [
                t39,
                t41
            ]
        });
        $[66] = t39;
        $[67] = t41;
        $[68] = t42;
    } else {
        t42 = $[68];
    }
    let t43;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
        t43 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.totalLabel,
            children: "NET A PAYER"
        });
        $[69] = t43;
    } else {
        t43 = $[69];
    }
    let t44;
    if ($[70] !== document.total) {
        t44 = formatCurrencyPDF(document.total);
        $[70] = document.total;
        $[71] = t44;
    } else {
        t44 = $[71];
    }
    let t45;
    if ($[72] !== t44) {
        t45 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalColLast,
            children: [
                t43,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: styles.totalVal,
                    children: t44
                })
            ]
        });
        $[72] = t44;
        $[73] = t45;
    } else {
        t45 = $[73];
    }
    let t46;
    if ($[74] !== t27 || $[75] !== t31 || $[76] !== t35 || $[77] !== t38 || $[78] !== t42 || $[79] !== t45) {
        t46 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.totalsSection,
            wrap: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.totalsContainer,
                children: [
                    t27,
                    t31,
                    t35,
                    t38,
                    t42,
                    t45
                ]
            })
        });
        $[74] = t27;
        $[75] = t31;
        $[76] = t35;
        $[77] = t38;
        $[78] = t42;
        $[79] = t45;
        $[80] = t46;
    } else {
        t46 = $[80];
    }
    let t47;
    if ($[81] === Symbol.for("react.memo_cache_sentinel")) {
        t47 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: styles.bankTitle,
            children: "Coordonn\xe9es pour Virement Bancaire"
        });
        $[81] = t47;
    } else {
        t47 = $[81];
    }
    let t48;
    if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
        t48 = {
            fontSize: 8
        };
        $[82] = t48;
    } else {
        t48 = $[82];
    }
    let t49;
    if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
        t49 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: {
                fontWeight: "bold"
            },
            children: "Banque:"
        });
        $[83] = t49;
    } else {
        t49 = $[83];
    }
    let t50;
    if ($[84] !== settings.bankName) {
        t50 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t48,
            children: [
                t49,
                " ",
                settings.bankName
            ]
        });
        $[84] = settings.bankName;
        $[85] = t50;
    } else {
        t50 = $[85];
    }
    let t51;
    if ($[86] === Symbol.for("react.memo_cache_sentinel")) {
        t51 = {
            fontSize: 8
        };
        $[86] = t51;
    } else {
        t51 = $[86];
    }
    let t52;
    if ($[87] === Symbol.for("react.memo_cache_sentinel")) {
        t52 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: {
                fontWeight: "bold"
            },
            children: "IBAN/RIB:"
        });
        $[87] = t52;
    } else {
        t52 = $[87];
    }
    let t53;
    if ($[88] !== settings.iban) {
        t53 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t51,
            children: [
                t52,
                " ",
                settings.iban
            ]
        });
        $[88] = settings.iban;
        $[89] = t53;
    } else {
        t53 = $[89];
    }
    let t54;
    if ($[90] !== t50 || $[91] !== t53) {
        t54 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: styles.bankSection,
            wrap: false,
            children: [
                t47,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                    style: styles.bankGrid,
                    children: [
                        t50,
                        t53
                    ]
                })
            ]
        });
        $[90] = t50;
        $[91] = t53;
        $[92] = t54;
    } else {
        t54 = $[92];
    }
    let t55;
    if ($[93] === Symbol.for("react.memo_cache_sentinel")) {
        t55 = {
            marginBottom: 40,
            fontSize: 10
        };
        $[93] = t55;
    } else {
        t55 = $[93];
    }
    let t56;
    if ($[94] === Symbol.for("react.memo_cache_sentinel")) {
        t56 = {
            fontWeight: "bold",
            marginBottom: 10
        };
        $[94] = t56;
    } else {
        t56 = $[94];
    }
    const t57 = type === "devis" ? "Le Pr\xE9sent devis" : "La Pr\xE9sente facture";
    let t58;
    if ($[95] !== t57) {
        t58 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t56,
            children: [
                "Arr\xeater ",
                t57,
                " \xe0 la Somme totale de : ... FCFA TTC"
            ]
        });
        $[95] = t57;
        $[96] = t58;
    } else {
        t58 = $[96];
    }
    let t59;
    if ($[97] === Symbol.for("react.memo_cache_sentinel")) {
        t59 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: {
                color: "#003399",
                fontSize: 9,
                fontWeight: "bold"
            },
            children: "N.B:"
        });
        $[97] = t59;
    } else {
        t59 = $[97];
    }
    let t60;
    if ($[98] === Symbol.for("react.memo_cache_sentinel")) {
        t60 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: {
                color: "#2CA02C",
                fontSize: 9
            },
            children: "- Les modes de r\xe8glement: *Esp\xe8ces ; *Ch\xe8ques ; *Virements ."
        });
        $[98] = t60;
    } else {
        t60 = $[98];
    }
    let t61;
    if ($[99] === Symbol.for("react.memo_cache_sentinel")) {
        t61 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: {
                color: "#2CA02C",
                fontSize: 9
            },
            children: "- Les d\xe9lais de r\xe8glement: *Au Comptant;"
        });
        $[99] = t61;
    } else {
        t61 = $[99];
    }
    let t62;
    if ($[100] !== t58) {
        t62 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: t55,
            wrap: false,
            children: [
                t58,
                t59,
                t60,
                t61
            ]
        });
        $[100] = t58;
        $[101] = t62;
    } else {
        t62 = $[101];
    }
    let t63;
    if ($[102] === Symbol.for("react.memo_cache_sentinel")) {
        t63 = {
            alignItems: "flex-end",
            marginBottom: 60
        };
        $[102] = t63;
    } else {
        t63 = $[102];
    }
    let t64;
    if ($[103] === Symbol.for("react.memo_cache_sentinel")) {
        t64 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: t63,
            wrap: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                style: {
                    fontWeight: "bold",
                    marginRight: 40
                },
                children: "La Direction"
            })
        });
        $[103] = t64;
    } else {
        t64 = $[103];
    }
    let t65;
    if ($[104] === Symbol.for("react.memo_cache_sentinel")) {
        t65 = [
            styles.footer,
            {
                borderTopWidth: 0
            }
        ];
        $[104] = t65;
    } else {
        t65 = $[104];
    }
    let t66;
    if ($[105] === Symbol.for("react.memo_cache_sentinel")) {
        t66 = {
            fontWeight: "bold",
            fontSize: 10,
            color: "#000",
            marginBottom: 2
        };
        $[105] = t66;
    } else {
        t66 = $[105];
    }
    let t67;
    if ($[106] !== settings.companyName) {
        t67 = settings.companyName.toUpperCase();
        $[106] = settings.companyName;
        $[107] = t67;
    } else {
        t67 = $[107];
    }
    let t68;
    if ($[108] !== t67) {
        t68 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            style: t66,
            children: t67
        });
        $[108] = t67;
        $[109] = t68;
    } else {
        t68 = $[109];
    }
    let t69;
    if ($[110] !== settings.phone) {
        t69 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "T\xe9l: ",
                settings.phone
            ]
        });
        $[110] = settings.phone;
        $[111] = t69;
    } else {
        t69 = $[111];
    }
    let t70;
    if ($[112] !== settings.address) {
        t70 = settings.address.split(",")[1]?.trim() || "111 LIBREVILLE";
        $[112] = settings.address;
        $[113] = t70;
    } else {
        t70 = $[113];
    }
    let t71;
    if ($[114] !== t70) {
        t71 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "BP: ",
                t70
            ]
        });
        $[114] = t70;
        $[115] = t71;
    } else {
        t71 = $[115];
    }
    let t72;
    if ($[116] !== settings.email) {
        t72 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "Email: ",
                settings.email
            ]
        });
        $[116] = settings.email;
        $[117] = t72;
    } else {
        t72 = $[117];
    }
    let t73;
    if ($[118] !== settings.nif || $[119] !== settings.rccm) {
        t73 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "NIF: ",
                settings.nif,
                " / RCCM: ",
                settings.rccm
            ]
        });
        $[118] = settings.nif;
        $[119] = settings.rccm;
        $[120] = t73;
    } else {
        t73 = $[120];
    }
    let t74;
    if ($[121] !== settings.iban) {
        t74 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
            children: [
                "Compte BGFI N\xb0: ",
                settings.iban
            ]
        });
        $[121] = settings.iban;
        $[122] = t74;
    } else {
        t74 = $[122];
    }
    let t75;
    if ($[123] !== t68 || $[124] !== t69 || $[125] !== t71 || $[126] !== t72 || $[127] !== t73 || $[128] !== t74) {
        t75 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
            style: t65,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.bottomCenter,
                children: [
                    t68,
                    t69,
                    t71,
                    t72,
                    t73,
                    t74
                ]
            })
        });
        $[123] = t68;
        $[124] = t69;
        $[125] = t71;
        $[126] = t72;
        $[127] = t73;
        $[128] = t74;
        $[129] = t75;
    } else {
        t75 = $[129];
    }
    let t76;
    if ($[130] !== t10 || $[131] !== t18 || $[132] !== t24 || $[133] !== t46 || $[134] !== t54 || $[135] !== t62 || $[136] !== t75) {
        t76 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Page */ .YW, {
            size: "A4",
            style: styles.page,
            children: [
                t10,
                t18,
                t24,
                t46,
                t54,
                t62,
                t64,
                t75
            ]
        });
        $[130] = t10;
        $[131] = t18;
        $[132] = t24;
        $[133] = t46;
        $[134] = t54;
        $[135] = t62;
        $[136] = t75;
        $[137] = t76;
    } else {
        t76 = $[137];
    }
    let t77;
    if ($[138] !== t2 || $[139] !== t76) {
        t77 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Document */ .yo, {
            title: t2,
            children: t76
        });
        $[138] = t2;
        $[139] = t76;
        $[140] = t77;
    } else {
        t77 = $[140];
    }
    return t77;
};
function _temp(item, index) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
        style: styles.tableRow,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.colDescription,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    children: item.description
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.colQty,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    children: item.quantity
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.colPrice,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    children: formatCurrencyPDF(item.unitPrice)
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .View */ .Ss, {
                style: styles.colTotal,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_3__/* .Text */ .EY, {
                    style: {
                        fontWeight: "bold"
                    },
                    children: formatCurrencyPDF(item.total)
                })
            })
        ]
    }, index);
}


/***/ })

}]);