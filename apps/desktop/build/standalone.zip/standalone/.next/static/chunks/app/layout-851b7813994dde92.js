(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[177],{

/***/ 23262:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ ChevronUp)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m18 15-6-6-6 6",
            key: "153udz"
        }
    ]
];
const ChevronUp = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("chevron-up", __iconNode);
 //# sourceMappingURL=chevron-up.js.map


/***/ }),

/***/ 37570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Yq: () => (/* binding */ formatDate),
/* harmony export */   cn: () => (/* binding */ cn),
/* harmony export */   vv: () => (/* binding */ formatCurrency)
/* harmony export */ });
/* unused harmony export formatShortCurrency */
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89279);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71563);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_0__/* .twMerge */ .QP)((0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)(inputs));
}
function formatCurrency(value) {
    return new Intl.NumberFormat("fr-FR", {
        style: "decimal",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(Math.round(value)).replace(/\u00a0/g, " ") + " FCFA";
}
function formatShortCurrency(value) {
    return formatCurrency(value);
}
function formatDate(dateString) {
    if (!dateString) return '';
    // Si c'est un format ISO strict YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateString.trim())) {
        const [year, month, day] = dateString.trim().split('-');
        return `${day}/${month}/${year}`;
    }
    // Fallback pour les timestamps complets (Date)
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat('fr-FR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    }).format(date);
}


/***/ }),

/***/ 50277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button),
/* harmony export */   r: () => (/* binding */ buttonVariants)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19749);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(36469);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6267);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(37570);






const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary-hover',
            success: 'bg-accent text-accent-foreground hover:bg-accent-hover',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-primary-light hover:text-primary dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-primary-light hover:text-primary dark:hover:bg-primary/20',
            link: 'text-primary underline-offset-4 hover:underline',
            'primary-shadow': 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button(t0) {
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(14);
    let className;
    let props;
    let size;
    let t1;
    let variant;
    if ($[0] !== t0) {
        ({ className, variant, size, asChild: t1, ...props } = t0);
        $[0] = t0;
        $[1] = className;
        $[2] = props;
        $[3] = size;
        $[4] = t1;
        $[5] = variant;
    } else {
        className = $[1];
        props = $[2];
        size = $[3];
        t1 = $[4];
        variant = $[5];
    }
    const asChild = t1 === undefined ? false : t1;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    let t2;
    if ($[6] !== className || $[7] !== size || $[8] !== variant) {
        t2 = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)(buttonVariants({
            variant,
            size,
            className
        }));
        $[6] = className;
        $[7] = size;
        $[8] = variant;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    let t3;
    if ($[10] !== Comp || $[11] !== props || $[12] !== t2) {
        t3 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
            "data-slot": "button",
            className: t2,
            ...props
        });
        $[10] = Comp;
        $[11] = props;
        $[12] = t2;
        $[13] = t3;
    } else {
        t3 = $[13];
    }
    return t3;
}



/***/ }),

/***/ 52014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ TriangleAlert)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }
    ],
    [
        "path",
        {
            d: "M12 9v4",
            key: "juzpu7"
        }
    ],
    [
        "path",
        {
            d: "M12 17h.01",
            key: "p32p05"
        }
    ]
];
const TriangleAlert = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("triangle-alert", __iconNode);
 //# sourceMappingURL=triangle-alert.js.map


/***/ }),

/***/ 52641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Providers: () => (/* binding */ Providers)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/compiler-runtime.js
var compiler_runtime = __webpack_require__(19749);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next-themes/dist/index.mjs
var dist = __webpack_require__(94849);
;// ./node_modules/react-error-boundary/dist/react-error-boundary.js
/* __next_internal_client_entry_do_not_use__ ErrorBoundary,ErrorBoundaryContext,getErrorMessage,useErrorBoundary,withErrorBoundary auto */ 
const h = /*#__PURE__*/ (0,react.createContext)(null), c = {
    didCatch: !1,
    error: null
};
class m extends react.Component {
    constructor(e){
        super(e), this.resetErrorBoundary = this.resetErrorBoundary.bind(this), this.state = c;
    }
    static getDerivedStateFromError(e) {
        return {
            didCatch: !0,
            error: e
        };
    }
    resetErrorBoundary(...e) {
        const { didCatch: t } = this.state;
        t && (this.props.onReset?.({
            args: e,
            reason: "imperative-api"
        }), this.setState(c));
    }
    componentDidCatch(e, t) {
        this.props.onError?.(e, t);
    }
    componentDidUpdate(e, t) {
        const { didCatch: o } = this.state, { resetKeys: s } = this.props;
        o && t.didCatch && C(e.resetKeys, s) && (this.props.onReset?.({
            next: s,
            prev: e.resetKeys,
            reason: "keys"
        }), this.setState(c));
    }
    render() {
        const { children: e, fallbackRender: t, FallbackComponent: o, fallback: s } = this.props, { didCatch: n, error: a } = this.state;
        let i = e;
        if (n) {
            const u = {
                error: a,
                resetErrorBoundary: this.resetErrorBoundary
            };
            if (typeof t == "function") i = t(u);
            else if (o) i = /*#__PURE__*/ (0,react.createElement)(o, u);
            else if (s !== void 0) i = s;
            else throw a;
        }
        return /*#__PURE__*/ (0,react.createElement)(h.Provider, {
            value: {
                didCatch: n,
                error: a,
                resetErrorBoundary: this.resetErrorBoundary
            }
        }, i);
    }
}
function C(r = [], e = []) {
    return r.length !== e.length || r.some((t, o)=>!Object.is(t, e[o]));
}
function g(r) {
    return r !== null && typeof r == "object" && "didCatch" in r && typeof r.didCatch == "boolean" && "error" in r && "resetErrorBoundary" in r && typeof r.resetErrorBoundary == "function";
}
function x(r) {
    if (!g(r)) throw new Error("ErrorBoundaryContext not found");
}
function k() {
    const r = l(h);
    x(r);
    const { error: e, resetErrorBoundary: t } = r, [o, s] = p({
        error: null,
        hasError: !1
    }), n = E(()=>({
            error: e,
            resetBoundary: ()=>{
                t(), s({
                    error: null,
                    hasError: !1
                });
            },
            showBoundary: (a)=>s({
                    error: a,
                    hasError: !0
                })
        }), [
        e,
        t
    ]);
    if (o.hasError) throw o.error;
    return n;
}
function S(r) {
    switch(typeof r){
        case "object":
            {
                if (r !== null && "message" in r && typeof r.message == "string") return r.message;
                break;
            }
        case "string":
            return r;
    }
}
function w(r, e) {
    const t = /*#__PURE__*/ B((s, n)=>/*#__PURE__*/ d(m, e, /*#__PURE__*/ d(r, {
            ...s,
            ref: n
        }))), o = r.displayName || r.name || "Unknown";
    return t.displayName = `withErrorBoundary(${o})`, t;
}
 //# sourceMappingURL=react-error-boundary.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/triangle-alert.js
var triangle_alert = __webpack_require__(52014);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(50277);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var sonner_dist = __webpack_require__(29094);
;// ./components/providers.tsx
/* __next_internal_client_entry_do_not_use__ Providers auto */ 







function FallbackError(t0) {
    const $ = (0,compiler_runtime.c)(10);
    const { error, resetErrorBoundary } = t0;
    let t1;
    let t2;
    let t3;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(triangle_alert/* default */.A, {
            className: "w-16 h-16 text-destructive mb-4"
        });
        t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
            className: "text-2xl font-bold text-slate-900 mb-2",
            children: "Une erreur inattendue est survenue"
        });
        t3 = /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
            className: "text-slate-500 mb-6 max-w-md",
            children: "Le composant applicatif a rencontr\xe9 un probl\xe8me. Veuillez rafra\xeechir la page ou retourner \xe0 l'accueil."
        });
        $[0] = t1;
        $[1] = t2;
        $[2] = t3;
    } else {
        t1 = $[0];
        t2 = $[1];
        t3 = $[2];
    }
    let t4;
    if ($[3] !== error.message) {
        t4 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "bg-slate-100 p-4 rounded-md mb-6 w-full max-w-lg text-left overflow-auto text-sm text-slate-800",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("code", {
                children: error.message
            })
        });
        $[3] = error.message;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] !== resetErrorBoundary) {
        t5 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
            onClick: resetErrorBoundary,
            children: "R\xe9essayer"
        });
        $[5] = resetErrorBoundary;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== t4 || $[8] !== t5) {
        t6 = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center",
            children: [
                t1,
                t2,
                t3,
                t4,
                t5
            ]
        });
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    return t6;
}
function Providers(t0) {
    const $ = (0,compiler_runtime.c)(5);
    const { children } = t0;
    let t1;
    if ($[0] !== children) {
        t1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(m, {
            FallbackComponent: FallbackError,
            children: children
        });
        $[0] = children;
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(sonner_dist/* Toaster */.l$, {
            position: "top-right",
            richColors: true
        });
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== t1) {
        t3 = /*#__PURE__*/ (0,jsx_runtime.jsxs)(dist/* ThemeProvider */.N, {
            attribute: "class",
            defaultTheme: "system",
            enableSystem: true,
            disableTransitionOnChange: false,
            children: [
                t1,
                t2
            ]
        });
        $[3] = t1;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}


/***/ }),

/***/ 66872:
/***/ (() => {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 72775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ ChevronDown)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15431);
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }
    ]
];
const ChevronDown = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("chevron-down", __iconNode);
 //# sourceMappingURL=chevron-down.js.map


/***/ }),

/***/ 74616:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 66872, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98340));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52641));


/***/ }),

/***/ 94849:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ z),
/* harmony export */   N: () => (/* binding */ J)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ ThemeProvider,useTheme auto */ 
var M = (e, i, s, u, m, a, l, h)=>{
    let d = document.documentElement, w = [
        "light",
        "dark"
    ];
    function p(n) {
        (Array.isArray(e) ? e : [
            e
        ]).forEach((y)=>{
            let k = y === "class", S = k && a ? m.map((f)=>a[f] || f) : m;
            k ? (d.classList.remove(...S), d.classList.add(a && a[n] ? a[n] : n)) : d.setAttribute(y, n);
        }), R(n);
    }
    function R(n) {
        h && w.includes(n) && (d.style.colorScheme = n);
    }
    function c() {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    if (u) p(u);
    else try {
        let n = localStorage.getItem(i) || s, y = l && n === "system" ? c() : n;
        p(y);
    } catch (n) {}
};
var b = [
    "light",
    "dark"
], I = "(prefers-color-scheme: dark)", O = "object" == "undefined", x = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createContext(void 0), U = {
    setTheme: (e)=>{},
    themes: []
}, z = ()=>{
    var e;
    return (e = react__WEBPACK_IMPORTED_MODULE_0__.useContext(x)) != null ? e : U;
}, J = (e)=>react__WEBPACK_IMPORTED_MODULE_0__.useContext(x) ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, e.children) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(V, {
        ...e
    }), N = [
    "light",
    "dark"
], V = ({ forcedTheme: e, disableTransitionOnChange: i = !1, enableSystem: s = !0, enableColorScheme: u = !0, storageKey: m = "theme", themes: a = N, defaultTheme: l = s ? "system" : "light", attribute: h = "data-theme", value: d, children: w, nonce: p, scriptProps: R })=>{
    let [c, n] = react__WEBPACK_IMPORTED_MODULE_0__.useState(()=>H(m, l)), [T, y] = react__WEBPACK_IMPORTED_MODULE_0__.useState(()=>c === "system" ? E() : c), k = d ? Object.values(d) : a, S = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((o)=>{
        let r = o;
        if (!r) return;
        o === "system" && s && (r = E());
        let v = d ? d[r] : r, C = i ? W(p) : null, P = document.documentElement, L = (g)=>{
            g === "class" ? (P.classList.remove(...k), v && P.classList.add(v)) : g.startsWith("data-") && (v ? P.setAttribute(g, v) : P.removeAttribute(g));
        };
        if (Array.isArray(h) ? h.forEach(L) : L(h), u) {
            let g = b.includes(l) ? l : null, D = b.includes(r) ? r : g;
            P.style.colorScheme = D;
        }
        C == null || C();
    }, [
        p
    ]), f = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((o)=>{
        let r = typeof o == "function" ? o(c) : o;
        n(r);
        try {
            localStorage.setItem(m, r);
        } catch (v) {}
    }, [
        c
    ]), A = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((o)=>{
        let r = E(o);
        y(r), c === "system" && s && !e && S("system");
    }, [
        c,
        e
    ]);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(()=>{
        let o = window.matchMedia(I);
        return o.addListener(A), A(o), ()=>o.removeListener(A);
    }, [
        A
    ]), react__WEBPACK_IMPORTED_MODULE_0__.useEffect(()=>{
        let o = (r)=>{
            r.key === m && (r.newValue ? n(r.newValue) : f(l));
        };
        return window.addEventListener("storage", o), ()=>window.removeEventListener("storage", o);
    }, [
        f
    ]), react__WEBPACK_IMPORTED_MODULE_0__.useEffect(()=>{
        S(e != null ? e : c);
    }, [
        e,
        c
    ]);
    let Q = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(()=>({
            theme: c,
            setTheme: f,
            forcedTheme: e,
            resolvedTheme: c === "system" ? T : c,
            themes: s ? [
                ...a,
                "system"
            ] : a,
            systemTheme: s ? T : void 0
        }), [
        c,
        f,
        e,
        T,
        s,
        a
    ]);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(x.Provider, {
        value: Q
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(_, {
        forcedTheme: e,
        storageKey: m,
        attribute: h,
        enableSystem: s,
        enableColorScheme: u,
        defaultTheme: l,
        value: d,
        themes: a,
        nonce: p,
        scriptProps: R
    }), w);
}, _ = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.memo(({ forcedTheme: e, storageKey: i, attribute: s, enableSystem: u, enableColorScheme: m, defaultTheme: a, value: l, themes: h, nonce: d, scriptProps: w })=>{
    let p = JSON.stringify([
        s,
        i,
        a,
        e,
        h,
        l,
        u,
        m
    ]).slice(1, -1);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement("script", {
        ...w,
        suppressHydrationWarning: !0,
        nonce:  false ? 0 : "",
        dangerouslySetInnerHTML: {
            __html: `(${M.toString()})(${p})`
        }
    });
}), H = (e, i)=>{
    if (O) return;
    let s;
    try {
        s = localStorage.getItem(e) || void 0;
    } catch (u) {}
    return s || i;
}, W = (e)=>{
    let i = document.createElement("style");
    return e && i.setAttribute("nonce", e), i.appendChild(document.createTextNode("*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")), document.head.appendChild(i), ()=>{
        window.getComputedStyle(document.body), setTimeout(()=>{
            document.head.removeChild(i);
        }, 1);
    };
}, E = (e)=>(e || (e = window.matchMedia(I)), e.matches ? "dark" : "light");



/***/ }),

/***/ 98340:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AppErrorBoundary: () => (/* binding */ AppErrorBoundary)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/triangle-alert.js
var triangle_alert = __webpack_require__(52014);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 7 modules
var createLucideIcon = __webpack_require__(15431);
;// ./node_modules/lucide-react/dist/esm/icons/refresh-cw.js
/**
 * @license lucide-react v0.564.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
            key: "v9h5vc"
        }
    ],
    [
        "path",
        {
            d: "M21 3v5h-5",
            key: "1q7to0"
        }
    ],
    [
        "path",
        {
            d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
            key: "3uifl3"
        }
    ],
    [
        "path",
        {
            d: "M8 16H3v5",
            key: "1cv678"
        }
    ]
];
const RefreshCw = (0,createLucideIcon/* default */.A)("refresh-cw", __iconNode);
 //# sourceMappingURL=refresh-cw.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-up.js
var chevron_up = __webpack_require__(23262);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-down.js
var chevron_down = __webpack_require__(72775);
;// ./components/error-boundary.tsx
/* __next_internal_client_entry_do_not_use__ AppErrorBoundary auto */ 
/**
 * AppErrorBoundary — Mur de protection contre les crashes React
 * ==============================================================
 * En contexte Electron/Desktop, un crash React sans Error Boundary
 * produit un écran BLANC TOTAL — sans message, sans possibilité de
 * récupération. L'utilisateur pense que l'application est gelée.
 *
 * Ce composant intercepte toute exception non gérée dans l'arbre
 * de composants enfants et affiche un écran de récupération propre
 * avec un bouton "Recharger" et les détails de l'erreur.
 */ 

class AppErrorBoundary extends react.Component {
    constructor(props){
        super(props), this.handleReload = ()=>{
            // Réinitialiser l'état de l'Error Boundary
            this.setState({
                hasError: false,
                error: null,
                errorInfo: null,
                showDetails: false
            });
            // Forcer un rechargement de la fenêtre si la réinitialisation de l'état ne suffit pas
            window.location.reload();
        }, this.toggleDetails = ()=>{
            this.setState((prev)=>({
                    showDetails: !prev.showDetails
                }));
        };
        this.state = {
            hasError: false,
            error: null,
            errorInfo: null,
            showDetails: false
        };
    }
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        this.setState({
            errorInfo
        });
        // En production Electron, loguer vers le fichier de logs
        console.error('[AppErrorBoundary] Crash capturé:', error.message, errorInfo.componentStack);
    }
    render() {
        if (!this.state.hasError) {
            return this.props.children;
        }
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "min-h-screen bg-background flex items-center justify-center p-8",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "max-w-lg w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-6",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(triangle_alert/* default */.A, {
                            className: "w-8 h-8 text-destructive"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                        className: "text-xl font-semibold text-foreground text-center tracking-tight mb-2",
                        children: "Une erreur inattendue s'est produite"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-sm text-muted-foreground text-center mb-8 leading-relaxed",
                        children: this.props.fallbackMessage || "L'application a rencontré un problème. Vos données sont en sécurité — la base de données n'a pas été affectée."
                    }),
                    this.state.error && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "bg-destructive/5 border border-destructive/20 rounded-xl p-4 mb-6",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                            className: "text-xs font-mono text-destructive break-all",
                            children: [
                                this.state.error.name,
                                ": ",
                                this.state.error.message
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex gap-3 mb-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                            onClick: this.handleReload,
                            className: "flex-1 flex items-center justify-center gap-2 h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-colors",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(RefreshCw, {
                                    className: "w-4 h-4"
                                }),
                                "Recharger l'application"
                            ]
                        })
                    }),
                    this.state.errorInfo && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                onClick: this.toggleDetails,
                                className: "w-full flex items-center justify-between p-3 rounded-xl text-xs text-muted-foreground hover:bg-secondary transition-colors",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "font-bold uppercase tracking-widest",
                                        children: "D\xe9tails techniques"
                                    }),
                                    this.state.showDetails ? /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_up/* default */.A, {
                                        className: "w-4 h-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_down/* default */.A, {
                                        className: "w-4 h-4"
                                    })
                                ]
                            }),
                            this.state.showDetails && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "mt-2 bg-secondary rounded-xl p-4 overflow-auto max-h-48",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("pre", {
                                    className: "text-[10px] font-mono text-muted-foreground whitespace-pre-wrap break-all",
                                    children: this.state.errorInfo.componentStack
                                })
                            })
                        ]
                    })
                ]
            })
        });
    }
}


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [513,878,441,826,358], () => (__webpack_exec__(74616)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);