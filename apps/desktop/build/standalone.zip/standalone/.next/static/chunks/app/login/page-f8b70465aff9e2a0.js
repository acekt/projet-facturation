(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[520],{

/***/ 49117:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83480));


/***/ }),

/***/ 83480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LoginClient)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js
var action_client_wrapper = __webpack_require__(24372);
;// ./node_modules/next/dist/build/webpack/loaders/next-flight-server-reference-proxy-loader.js?id=40e1299e8877a42d59383348712170112a67f82e5a&name=loginUser!

const loginUser = /*#__PURE__*/(0,action_client_wrapper.createServerReference)("40e1299e8877a42d59383348712170112a67f82e5a", action_client_wrapper.callServer, undefined, action_client_wrapper.findSourceMapURL, "loginUser")
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(82222);
// EXTERNAL MODULE: ./lib/store.ts
var store = __webpack_require__(43922);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(34819);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(50277);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(29094);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 4 modules
var AnimatePresence = __webpack_require__(30091);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs + 249 modules
var proxy = __webpack_require__(4341);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(73981);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/user.js
var user = __webpack_require__(13594);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/eye-off.js
var eye_off = __webpack_require__(99074);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/lock.js
var lock = __webpack_require__(16846);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/loader-circle.js
var loader_circle = __webpack_require__(42601);
;// ./app/login/login-client.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function LoginClient() {
    const [username, setUsername] = react.useState("");
    const [password, setPassword] = react.useState("");
    const [isSubmitting, setIsSubmitting] = react.useState(false);
    const [showPassword, setShowPassword] = react.useState(false);
    const [currentSlide, setCurrentSlide] = react.useState(0);
    const [rememberMe, setRememberMe] = react.useState(false);
    const [isForgotPassword, setIsForgotPassword] = react.useState(false);
    const router = (0,navigation.useRouter)();
    const searchParams = (0,navigation.useSearchParams)();
    const setUser = (0,store/* useStore */.P)((state)=>state.setUser);
    // Charger le nom d'utilisateur mémorisé au démarrage
    react.useEffect(()=>{
        const savedUsername = localStorage.getItem("facturier_remembered_username");
        if (savedUsername) {
            setUsername(savedUsername);
            setRememberMe(true);
        }
    }, []);
    // Gérer l'affichage des erreurs provenant des redirections du middleware
    react.useEffect(()=>{
        const errorParam = searchParams.get("error");
        if (errorParam) {
            // Nettoyer l'URL sans recharger la page
            const url = new URL(window.location.href);
            url.searchParams.delete("error");
            window.history.replaceState({}, "", url.toString());
            if (errorParam === "forbidden") {
                dist/* toast */.oR.error("Accès non autorisé");
            } else if (errorParam === "session_expired") {
                dist/* toast */.oR.error("Votre session a expiré");
            } else {
                dist/* toast */.oR.error("Une erreur est survenue");
            }
        }
    }, [
        searchParams
    ]);
    // Données du carrousel
    const slides = react.useMemo(()=>[
            {
                image: "/login-img-2.svg",
                title: "Gérez avec excellence",
                text: "La solution locale et conforme pour piloter vos factures en toute sérénité."
            },
            {
                image: "/login-img-3.svg",
                title: "Conformité Garantie",
                text: "Calcul strict des taxes locales (TVA, TPS) selon les normes en vigueur."
            },
            {
                image: "/login-img-4.svg",
                title: "Résilience Hors-Ligne",
                text: "Vos données restent accessibles et ultra-rapides, même sans connexion internet."
            }
        ], []);
    // Timer automatique du carrousel
    react.useEffect(()=>{
        const timer = setInterval(()=>{
            setCurrentSlide((prev)=>(prev + 1) % slides.length);
        }, 5000);
        return ()=>clearInterval(timer);
    }, [
        slides.length
    ]);
    // Soumission du formulaire
    const handleLogin = async (e)=>{
        e.preventDefault();
        if (isSubmitting) return;
        setIsSubmitting(true);
        try {
            const res = await loginUser({
                username,
                password
            });
            if (res.success) {
                // Sauvegarder ou oublier l'email selon la case cochée
                if (rememberMe) {
                    localStorage.setItem("facturier_remembered_username", username);
                } else {
                    localStorage.removeItem("facturier_remembered_username");
                }
                dist/* toast */.oR.success("Connexion réussie. Bienvenue dans Facturier !");
                setUser(res.data.user);
                await new Promise((resolve)=>setTimeout(resolve, 250));
                router.push("/");
                router.refresh();
            } else {
                dist/* toast */.oR.error(res.error || "Identifiants invalides");
            }
        } catch (err) {
            if (err instanceof Error) {
                dist/* toast */.oR.error(`Erreur serveur: ${err.message}`);
            } else {
                dist/* toast */.oR.error("Impossible de joindre le serveur local");
            }
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleForgotPassword = (e_0)=>{
        e_0.preventDefault();
        if (!username) {
            dist/* toast */.oR.error("Veuillez saisir votre email");
            return;
        }
        // Simulation API
        dist/* toast */.oR.success("Si ce compte existe, un email de réinitialisation vous a été envoyé.");
        setIsForgotPassword(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "h-screen w-screen overflow-hidden flex bg-background transition-colors duration-300",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full h-full flex flex-col md:flex-row",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "hidden md:flex flex-col relative w-[45%] h-full bg-primary overflow-hidden p-10 justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative z-10",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-2 mb-12",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "relative w-12 h-12 bg-white rounded-lg shadow-md overflow-hidden",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                                src: "/logo.png",
                                                alt: "Logo Facturier",
                                                fill: true,
                                                className: "object-contain p-1"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                            className: "text-primary-foreground font-bold text-xl tracking-tight",
                                            children: "Facturier"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "relative h-[480px]",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(AnimatePresence/* AnimatePresence */.N, {
                                        mode: "wait",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.P.div, {
                                            initial: {
                                                opacity: 0,
                                                y: 20
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            exit: {
                                                opacity: 0,
                                                y: -20
                                            },
                                            transition: {
                                                duration: 0.5,
                                                ease: "easeOut"
                                            },
                                            className: "absolute inset-0 flex flex-col h-full",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex-1 flex items-center justify-center mb-8 relative",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "absolute inset-0 bg-primary-foreground/5 rounded-3xl blur-2xl"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "relative w-[340px] h-[340px] drop-shadow-2xl",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                                                src: slides[currentSlide].image,
                                                                alt: slides[currentSlide].title,
                                                                fill: true,
                                                                className: "object-contain filter brightness-[1.1] contrast-[1.05]",
                                                                priority: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "mt-auto",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                                            className: "text-3xl font-bold text-primary-foreground mb-4 tracking-tight leading-tight",
                                                            children: slides[currentSlide].title
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-primary-foreground/80 text-[15px] leading-relaxed max-w-md font-medium",
                                                            children: slides[currentSlide].text
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, currentSlide)
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center gap-2 mt-12",
                                    children: slides.map((_, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                            onClick: ()=>setCurrentSlide(index),
                                            "aria-label": `Slide ${index + 1}`,
                                            className: `h-1.5 rounded-full transition-all duration-300 ${currentSlide === index ? "w-8 bg-primary-foreground" : "w-2 bg-primary-foreground/30 hover:bg-primary-foreground/50"}`
                                        }, index))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 right-0 w-[800px] h-[800px] bg-primary-foreground/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute bottom-0 left-0 w-[600px] h-[600px] bg-primary-foreground/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4 pointer-events-none"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex-1 flex flex-col justify-center items-center p-8 sm:p-12 md:p-16 relative bg-background overflow-y-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "w-full max-w-[380px] space-y-10 my-auto",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-center space-y-2 mb-8",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "flex justify-center mb-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center ring-4 ring-background shadow-sm",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(user/* default */.A, {
                                                className: "w-8 h-8 text-primary"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                                        className: "text-2xl sm:text-3xl font-bold text-foreground tracking-tight",
                                        children: isForgotPassword ? "Mot de passe oublié" : "Bienvenue"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-sm text-muted-foreground leading-relaxed font-medium",
                                        children: isForgotPassword ? "Entrez votre adresse email pour réinitialiser votre accès." : "Connectez-vous à Facturier pour gérer votre activité."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                                onSubmit: isForgotPassword ? handleForgotPassword : handleLogin,
                                className: "space-y-6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                                        htmlFor: "username",
                                                        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                                                        children: "Email"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                        id: "username",
                                                        type: "email",
                                                        value: username,
                                                        onChange: (e_1)=>setUsername(e_1.target.value),
                                                        placeholder: "jean@facturier.ga",
                                                        className: "bg-secondary border-border text-foreground",
                                                        required: true,
                                                        disabled: isSubmitting
                                                    })
                                                ]
                                            }),
                                            !isForgotPassword && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                                        htmlFor: "password",
                                                        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                                                        children: "Mot de passe"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "relative",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                id: "password",
                                                                type: showPassword ? "text" : "password",
                                                                value: password,
                                                                onChange: (e_2)=>setPassword(e_2.target.value),
                                                                placeholder: "••••••••",
                                                                className: "bg-secondary border-border text-foreground pr-10",
                                                                required: true,
                                                                disabled: isSubmitting
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                type: "button",
                                                                variant: "ghost",
                                                                size: "icon",
                                                                className: "absolute right-0 top-0 h-full px-3 text-muted-foreground hover:text-foreground",
                                                                "aria-label": showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe",
                                                                onClick: ()=>setShowPassword(!showPassword),
                                                                children: showPassword ? /*#__PURE__*/ (0,jsx_runtime.jsx)(eye_off/* default */.A, {
                                                                    className: "w-4 h-4"
                                                                }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(lock/* default */.A, {
                                                                    className: "w-4 h-4"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    !isForgotPassword && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "flex items-center justify-between pt-1",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                className: "flex items-center gap-2 cursor-pointer group",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                                        type: "checkbox",
                                                        checked: rememberMe,
                                                        onChange: (e_3)=>setRememberMe(e_3.target.checked),
                                                        className: "w-4 h-4 rounded border-border text-primary focus:ring-primary cursor-pointer"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        className: "text-[13px] text-muted-foreground font-medium select-none group-hover:text-foreground transition-colors",
                                                        children: "Se souvenir de moi"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                                type: "button",
                                                onClick: ()=>setIsForgotPassword(true),
                                                className: "text-[13px] font-bold text-primary hover:text-primary/80 transition-colors",
                                                children: "Mot de passe oubli\xe9 ?"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "pt-2 flex flex-col gap-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                type: "submit",
                                                className: "w-full bg-primary hover:bg-primary/90 text-primary-foreground",
                                                disabled: isSubmitting,
                                                children: isSubmitting ? /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(loader_circle/* default */.A, {
                                                            className: "w-4 h-4 animate-spin mr-2"
                                                        }),
                                                        " ",
                                                        isForgotPassword ? "Envoi..." : "Connexion..."
                                                    ]
                                                }) : isForgotPassword ? "Réinitialiser le mot de passe" : "Se connecter"
                                            }),
                                            isForgotPassword && /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                type: "button",
                                                variant: "ghost",
                                                className: "w-full",
                                                onClick: ()=>setIsForgotPassword(false),
                                                children: "Retour \xe0 la connexion"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
}


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [878,804,568,366,680,441,826,358], () => (__webpack_exec__(49117)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);