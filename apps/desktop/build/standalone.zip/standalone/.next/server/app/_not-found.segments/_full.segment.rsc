1:"$Sreact.fragment"
2:I[98340,["878","static/chunks/878-c394f4953ba093d1.js","177","static/chunks/app/layout-851b7813994dde92.js"],"AppErrorBoundary"]
3:I[52641,["878","static/chunks/878-c394f4953ba093d1.js","177","static/chunks/app/layout-851b7813994dde92.js"],"Providers"]
4:I[68172,[],""]
5:I[97210,[],""]
6:I[78937,[],"OutletBoundary"]
7:"$Sreact.suspense"
c:I[78937,[],"ViewportBoundary"]
e:I[78937,[],"MetadataBoundary"]
10:I[65704,[],"default",1]
:HL["/_next/static/css/d1b9f152d48679b5.css","style"]
9:X
a:X
b:X
11:X
12:X
13:X
0:{"P":null,"c":["","_not-found"],"q":"","i":false,"f":[[["",{"children":["_not-found",{"children":["__PAGE__",{},"$undefined","$undefined",4608]},"$undefined","$undefined",4608]},"$undefined","$undefined",4624],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/d1b9f152d48679b5.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"fr","suppressHydrationWarning":true,"className":"bg-background","children":["$","body",null,{"className":"font-sans antialiased bg-background text-foreground select-none","children":["$","$L2",null,{"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],null,["$","$L6",null,{"children":["$","$7",null,{"name":"Next.MetadataOutlet","children":"$@8"}]}]]}],{},null,true,"$9"]},null,true,"$a"]},null,true,"$b"],["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$Lc",null,{"children":"$Ld"}],["$","div",null,{"hidden":true,"children":["$","$Le",null,{"children":["$","$7",null,{"name":"Next.Metadata","children":"$Lf"}]}]}],null]}],true]],"m":"$undefined","G":["$10",[]],"S":true,"h":"$11","r":"$12","s":"$13","a":"$@14","l":"$undefined","p":"$undefined","d":"$undefined","b":"4K2pkQKaOfVQNTny1SLFR","u":"$@15"}
a:C
13:300
d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
8:null
f:[["$","title","0",{"children":"Facturier — Gestion & Facturation"}]]
13:C
11:C
12:C
9:C
b:C
15:false
14:null
