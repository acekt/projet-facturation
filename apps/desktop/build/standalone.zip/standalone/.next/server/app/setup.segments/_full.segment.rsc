1:"$Sreact.fragment"
2:I[98340,["878","static/chunks/878-c394f4953ba093d1.js","177","static/chunks/app/layout-851b7813994dde92.js"],"AppErrorBoundary"]
3:I[52641,["878","static/chunks/878-c394f4953ba093d1.js","177","static/chunks/app/layout-851b7813994dde92.js"],"Providers"]
4:I[68172,[],""]
5:I[97210,[],""]
7:I[78937,[],"OutletBoundary"]
8:"$Sreact.suspense"
d:I[78937,[],"ViewportBoundary"]
f:I[78937,[],"MetadataBoundary"]
11:I[65704,[],"default",1]
:HL["/_next/static/css/d1b9f152d48679b5.css","style"]
a:X
b:X
c:X
12:X
13:X
14:X
0:{"P":null,"c":["","setup"],"q":"","i":false,"f":[[["",{"children":["setup",{"children":["__PAGE__",{},"$undefined","$undefined",12800]},"$undefined","$undefined",12800]},"$undefined","$undefined",12816],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/d1b9f152d48679b5.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"fr","suppressHydrationWarning":true,"className":"bg-background","children":["$","body",null,{"className":"font-sans antialiased bg-background text-foreground select-none","children":["$","$L2",null,{"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":["$L6",null,["$","$L7",null,{"children":["$","$8",null,{"name":"Next.MetadataOutlet","children":"$@9"}]}]]}],{},null,true,"$a"]},null,true,"$b"]},null,true,"$c"],["$","$1","h",{"children":[null,["$","$Ld",null,{"children":"$Le"}],["$","div",null,{"hidden":true,"children":["$","$Lf",null,{"children":["$","$8",null,{"name":"Next.Metadata","children":"$L10"}]}]}],null]}],true]],"m":"$undefined","G":["$11",[]],"S":true,"h":"$12","r":"$13","s":"$14","a":"$@15","l":"$undefined","p":"$undefined","d":"$undefined","b":"4K2pkQKaOfVQNTny1SLFR","u":"$@16"}
b:C
14:300
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
9:null
10:[["$","title","0",{"children":"Facturier — Gestion & Facturation"}]]
14:C
12:C
13:C
a:C
c:C
16:false
15:null
