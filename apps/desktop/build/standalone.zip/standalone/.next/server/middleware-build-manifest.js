globalThis.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills-42372ed130431b0a.js"
  ],
  "devFiles": [],
  "lowPriorityFiles": [
    "static/4K2pkQKaOfVQNTny1SLFR/_buildManifest.js",
    "static/4K2pkQKaOfVQNTny1SLFR/_ssgManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/webpack-a04bc3d46bcfc980.js",
    "static/chunks/4bd1b696-c659a78d4965c18d.js",
    "static/chunks/826-a1cd231ef50140cc.js",
    "static/chunks/main-app-fd65faffb966db22.js"
  ],
  "rootMainFilesTree": {},
  "pages": {
    "/_app": []
  }
};
