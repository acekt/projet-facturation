exports.id=149,exports.ids=[149],exports.modules={8216:(a,b,c)=>{"use strict";let d;c.d(b,{A:()=>r});var e=c(87550),f=c.n(e),g=c(33873),h=c.n(g),i=c(29021),j=c.n(i),k=c(21820),l=c.n(k);let m=globalThis,n=function(){let a=process.env.TEST_DB_PATH;if(a){let b=h().resolve(a);return console.log(`[db] Niveau 0 (Test/E2E) : ${b}`),b}let b=process.env.DB_FILE_NAME||"database.sqlite",c=process.env.ELECTRON_USERDATA_PATH;if(c){let a=h().join(c,"data");try{j().existsSync(a)||j().mkdirSync(a,{recursive:!0});let c=h().resolve(h().join(a,b));return console.log(`[db] Niveau 1 (Electron userData) : ${c}`),c}catch(a){console.error("[db] NIVEAU 1 \xc9CHOU\xc9 — impossible d'\xe9crire dans ELECTRON_USERDATA_PATH :",a)}}let d=h().join(l().homedir(),".facturier-invoicing","data");try{j().existsSync(d)||j().mkdirSync(d,{recursive:!0})}catch(a){console.error("[db] NIVEAU 3 \xc9CHOU\xc9 — impossible de cr\xe9er le r\xe9pertoire homedir :",a)}let e=h().resolve(h().join(d,b));return console.warn(`[db] Niveau 3 (Fallback homedir) : ${e}`),e}();try{d=m.db||new(f())(n,{timeout:5e3}),m.db||(m.db=d,m.db_ready=!1)}catch(a){throw process.stderr.write(`[db] FATAL: Impossible d'ouvrir la base de donn\xe9es : ${n}
`),process.stderr.write(`[db] FATAL: ${a?.message||a}
`),process.stderr.write(`[db] FATAL: V\xe9rifiez l'ABI de better_sqlite3.node et les droits d'acc\xe8s au r\xe9pertoire.
`),a}d.pragma("foreign_keys = ON"),d.pragma("journal_mode = WAL"),d.pragma("synchronous = NORMAL");let o=()=>{if(!m.isClosing){m.isClosing=!0;try{if(d&&d.open){try{d.pragma("wal_checkpoint(TRUNCATE)")}catch(a){}d.close(),console.log("[db] Base de donn\xe9es SQLite ferm\xe9e proprement (WAL Checkpoint & Close).")}}catch(a){console.error("[db] Erreur lors de la fermeture de la base de donn\xe9es:",a)}}};m.isClosing||(process.on("exit",o),process.on("beforeExit",o),process.on("SIGINT",()=>{o(),process.exit(0)}),process.on("SIGTERM",()=>{o(),process.exit(0)}),process.on("SIGHUP",()=>{o(),process.exit(0)}),process.on("SIGBREAK",()=>{o(),process.exit(0)}));let p=m.statementCache||new Map;function q(a){let b=p.get(a);return b||(b=d.prepare(a),p.set(a,b)),b}m.statementCache=p;try{d.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    companyName TEXT,
    legalForm TEXT,
    nif TEXT,
    rccm TEXT,
    address TEXT,
    email TEXT,
    phone TEXT,
    bankName TEXT,
    bankAgency TEXT,
    accountNumber TEXT,
    swiftCode TEXT,
    iban TEXT,
    tvaRate REAL,
    tpsRate REAL DEFAULT 9.5,
    cssRate REAL,
    sessionTimeout INTEGER,
    invoicePrefix TEXT,
    quotePrefix TEXT,
    companyCode TEXT,
    mentionsLegales TEXT,
    logo TEXT
  );

  CREATE TABLE IF NOT EXISTS clients (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    address TEXT,
    status TEXT DEFAULT 'active',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT
  );

  CREATE TABLE IF NOT EXISTS quotes (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    clientId TEXT NOT NULL,
    clientName TEXT,
    clientEmail TEXT,
    date TEXT NOT NULL,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'EN_ATTENTE',
    notes TEXT,
    subject TEXT,
    validUntil TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (clientId) REFERENCES clients(id)
  );

  CREATE TABLE IF NOT EXISTS quote_items (
    id TEXT PRIMARY KEY,
    quoteId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (quoteId) REFERENCES quotes(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    quoteId TEXT,
    clientId TEXT NOT NULL,
    clientName TEXT,
    clientEmail TEXT,
    date TEXT NOT NULL,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'UNPAID',
    notes TEXT,
    subject TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (clientId) REFERENCES clients(id),
    FOREIGN KEY (quoteId) REFERENCES quotes(id)
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    amount REAL NOT NULL,
    paymentMethod TEXT NOT NULL,
    date TEXT NOT NULL,
    reference TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS sequences (
    name TEXT PRIMARY KEY,
    current_value INTEGER DEFAULT 0,
    last_year INTEGER


  );

  INSERT OR IGNORE INTO sequences (name, current_value, last_year) VALUES ('quote', 0, strftime('%Y', 'now'));
  INSERT OR IGNORE INTO sequences (name, current_value, last_year) VALUES ('invoice', 0, strftime('%Y', 'now'));

  CREATE TABLE IF NOT EXISTS services (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    unitPrice REAL DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT CHECK(role IN ('admin', 'user')) NOT NULL DEFAULT 'user',
    is_active INTEGER NOT NULL DEFAULT 1,
    force_password_change INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME,
    created_by TEXT,
    phone TEXT,
    deletedAt DATETIME
  );

  CREATE TABLE IF NOT EXISTS credit_notes (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    invoiceId TEXT NOT NULL,
    clientId TEXT NOT NULL,
    clientName TEXT,
    date TEXT NOT NULL,
    reason TEXT,
    subtotal REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'open',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    deletedAt DATETIME,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id),
    FOREIGN KEY (clientId) REFERENCES clients(id)
  );

  CREATE TABLE IF NOT EXISTS credit_note_items (
    id TEXT PRIMARY KEY,
    creditNoteId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (creditNoteId) REFERENCES credit_notes(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    userId TEXT,
    userName TEXT,
    action TEXT NOT NULL,
    entityType TEXT NOT NULL,
    entityId TEXT,
    details TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),m.db.pragma("journal_mode = WAL"),process.env.NEXT_BUILD||(m.db_ready=!0,process.stdout.write(`[db] Sch\xe9ma initialis\xe9 avec succ\xe8s : ${n}
`))}catch(a){throw process.stderr.write(`[db] FATAL: \xc9chec de l'initialisation du sch\xe9ma sur : ${n}
`),process.stderr.write(`[db] FATAL: ${a?.message||a}
`),a}try{let a=d.prepare("PRAGMA table_info(users)").all();a.some(a=>"is_active"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1").run(),a.some(a=>"force_password_change"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN force_password_change INTEGER NOT NULL DEFAULT 0").run(),a.some(a=>"last_login_at"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN last_login_at DATETIME").run(),a.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN created_by TEXT").run(),a.some(a=>"email"===a.name)||(d.prepare("ALTER TABLE users ADD COLUMN email TEXT").run(),d.prepare("UPDATE users SET email = username WHERE email IS NULL").run()),a.some(a=>"created_at"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP").run(),a.some(a=>"phone"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN phone TEXT").run(),a.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN deletedAt DATETIME").run()}catch(a){console.error("Migration error on users table:",a)}try{let a=d.prepare("PRAGMA table_info(quotes)").all();a.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN created_by TEXT").run(),a.some(a=>"subject"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN subject TEXT").run(),a.some(a=>"validUntil"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN validUntil TEXT").run();let b=d.prepare("PRAGMA table_info(invoices)").all();b.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN created_by TEXT").run(),b.some(a=>"subject"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN subject TEXT").run();let c=d.prepare("PRAGMA table_info(services)").all();c.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE services ADD COLUMN created_by TEXT").run(),b.some(a=>"dueDate"===a.name)||(d.prepare("ALTER TABLE invoices ADD COLUMN dueDate TEXT").run(),d.prepare("UPDATE invoices SET dueDate = date(date, '+30 days') WHERE dueDate IS NULL").run()),d.prepare("UPDATE invoices SET status = 'UNPAID' WHERE status IN ('pending', 'sent', 'open')").run(),d.prepare("UPDATE invoices SET status = 'PAID' WHERE status = 'paid'").run(),d.prepare("UPDATE invoices SET status = 'PARTIALLY_PAID' WHERE status IN ('partially_paid', 'partial')").run(),d.prepare("PRAGMA table_info(settings)").all().some(a=>"tpsRate"===a.name)||d.prepare("ALTER TABLE settings ADD COLUMN tpsRate REAL DEFAULT 9.5").run(),a.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN tpsAmount REAL DEFAULT 0").run(),b.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN tpsAmount REAL DEFAULT 0").run();let e=d.prepare("PRAGMA table_info(credit_notes)").all();e.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN tpsAmount REAL DEFAULT 0").run(),e.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN created_by TEXT").run();let f=d.prepare("PRAGMA table_info(clients)").all();f.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE clients ADD COLUMN deletedAt DATETIME").run(),f.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE clients ADD COLUMN created_by TEXT").run(),c.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE services ADD COLUMN deletedAt DATETIME").run(),e.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN deletedAt DATETIME").run();let g=d.prepare("PRAGMA table_info(payments)").all();g.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE payments ADD COLUMN deletedAt DATETIME").run(),g.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE payments ADD COLUMN created_by TEXT").run()}catch(a){console.error("Migration error:",a)}d.exec(`
  CREATE INDEX IF NOT EXISTS idx_clients_deletedAt ON clients(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_deletedAt ON quotes(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_clientId ON quotes(clientId);
  CREATE INDEX IF NOT EXISTS idx_invoices_deletedAt ON invoices(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_clientId ON invoices(clientId);
  CREATE INDEX IF NOT EXISTS idx_invoices_quoteId ON invoices(quoteId);
  CREATE INDEX IF NOT EXISTS idx_payments_deletedAt ON payments(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_payments_invoiceId ON payments(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_payments_created_by ON payments(created_by);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_deletedAt ON credit_notes(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_invoiceId ON credit_notes(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_clientId ON credit_notes(clientId);
  CREATE INDEX IF NOT EXISTS idx_services_deletedAt ON services(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quote_items_quoteId ON quote_items(quoteId);
  CREATE INDEX IF NOT EXISTS idx_invoice_items_invoiceId ON invoice_items(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_credit_note_items_creditNoteId ON credit_note_items(creditNoteId);
  
  -- Users optimizations
  CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);
  CREATE INDEX IF NOT EXISTS idx_users_deletedAt ON users(deletedAt);

  -- High Performance Indices (Phase 2 Architect)
  CREATE INDEX IF NOT EXISTS idx_invoices_status_deleted ON invoices(status, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_created_by ON invoices(created_by);
  CREATE INDEX IF NOT EXISTS idx_quotes_status_deleted ON quotes(status, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_created_by ON quotes(created_by);
  CREATE INDEX IF NOT EXISTS idx_payments_invoice_deleted ON payments(invoiceId, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_dashboard ON invoices(deletedAt, status, created_by);
  CREATE INDEX IF NOT EXISTS idx_quotes_dashboard ON quotes(deletedAt, status, created_by);
  CREATE INDEX IF NOT EXISTS idx_clients_deleted ON clients(deletedAt);
`);try{d.prepare("UPDATE payments SET created_by = (SELECT created_by FROM invoices WHERE id = payments.invoiceId) WHERE created_by IS NULL").run();let a=d.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();a?.id&&(d.prepare("UPDATE clients SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE services SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE quotes SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE invoices SET created_by = ? WHERE created_by IS NULL").run(a.id))}catch(a){console.error("Backfilling & Orphans Cleanup error:",a)}let r=new Proxy(d,{get(a,b,c){if("prepare"===b)return q;let d=Reflect.get(a,b,c);return"function"==typeof d?d.bind(a):d}})},8422:(a,b,c)=>{"use strict";c.d(b,{p:()=>f});var d=c(48249);c(67484);var e=c(33191);function f({className:a,type:b,...c}){return(0,d.jsx)("input",{type:b,"data-slot":"input",className:(0,e.cn)("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",a),...c})}},9207:(a,b,c)=>{"use strict";c.d(b,{P:()=>i});var d=c(31417),e=c(300);let f={canViewDashboard:!0,canViewSettings:!0,canViewAuditLog:!0,canViewUsers:!0,canManageUsers:!0,canViewCustomers:!1,canViewQuotes:!1,canCreateQuote:!1,canViewInvoices:!1,canViewServices:!1,canResetPassword:!0,canDeactivateUser:!0},g={canViewDashboard:!0,canViewSettings:!0,canViewAuditLog:!1,canViewUsers:!1,canManageUsers:!1,canViewCustomers:!0,canViewQuotes:!0,canCreateQuote:!0,canViewInvoices:!0,canViewServices:!0,canResetPassword:!1,canDeactivateUser:!1},h={id:1,companyName:"Global Maintenance",legalForm:"SARL",nif:"XXXXXXXXXX",rccm:"GA-LBV-XX-XXXX-XXXX",address:"123 Boulevard Triomphal, Libreville, Gabon",email:"facturation@globalm.ga",phone:"+241 01 76 XX XX",bankName:"BGFI Bank",bankAgency:"Libreville",accountNumber:"XXXXXXXXXX",swiftCode:"BGFIGAXX",iban:"GAXX XXXX XXXX XXXX XXXX",tvaRate:18,tpsRate:9.5,cssRate:1,sessionTimeout:30,invoicePrefix:"FAC",quotePrefix:"DEV",companyCode:"GM",mentionsLegales:null,logo:null},i=(0,d.v)()((0,e.Zr)(a=>({user:null,permissions:null,isAuthenticated:!1,isDataLoaded:!1,clients:[],quotes:[],invoices:[],services:[],payments:[],creditNotes:[],settings:h,users:[],dashboardMetrics:null,viewFormat:{quotes:"table",invoices:"table",clients:"block",services:"block",creditNotes:"horizontal"},invoiceDraft:{selectedClient:null,items:[{id:"1",description:"",quantity:1,unitPrice:0,total:0}],invoiceDate:new Date().toISOString().split("T")[0],discount:0,notes:""},quoteDraft:{selectedClient:null,items:[{id:"1",description:"",quantity:1,unitPrice:0,total:0}],quoteDate:new Date().toISOString().split("T")[0],discount:0,notes:"",status:"EN_ATTENTE"},setIsDataLoaded:b=>a({isDataLoaded:b}),setDashboardMetrics:b=>a({dashboardMetrics:b}),setUser:b=>{let c=b?"admin"===b.role?f:g:null;a({user:b,permissions:c,isAuthenticated:!!b})},setClients:b=>a({clients:b}),addClient:b=>a(a=>({clients:[...a.clients,b]})),removeClient:b=>a(a=>({clients:a.clients.filter(a=>a.id!==b)})),updateClient:(b,c)=>a(a=>({clients:a.clients.map(a=>a.id===b?{...a,...c}:a)})),replaceClient:(b,c)=>a(a=>({clients:a.clients.map(a=>a.id===b?c:a)})),setQuotes:b=>a({quotes:b}),addQuote:b=>a(a=>({quotes:[b,...a.quotes]})),removeQuote:b=>a(a=>({quotes:a.quotes.filter(a=>a.id!==b)})),updateQuote:(b,c)=>a(a=>({quotes:a.quotes.map(a=>a.id===b?{...a,...c}:a)})),replaceQuote:(b,c)=>a(a=>({quotes:a.quotes.map(a=>a.id===b?c:a)})),setInvoices:b=>a({invoices:b}),addInvoice:b=>a(a=>({invoices:[b,...a.invoices]})),removeInvoice:b=>a(a=>({invoices:a.invoices.filter(a=>a.id!==b)})),updateInvoice:(b,c)=>a(a=>({invoices:a.invoices.map(a=>a.id===b?{...a,...c}:a)})),replaceInvoice:(b,c)=>a(a=>({invoices:a.invoices.map(a=>a.id===b?c:a)})),setServices:b=>a({services:b}),addService:b=>a(a=>({services:[...a.services,b]})),removeService:b=>a(a=>({services:a.services.filter(a=>a.id!==b)})),updateService:(b,c)=>a(a=>({services:a.services.map(a=>a.id===b?{...a,...c}:a)})),replaceService:(b,c)=>a(a=>({services:a.services.map(a=>a.id===b?c:a)})),setPayments:b=>a({payments:b}),addPayment:b=>a(a=>({payments:[b,...a.payments]})),removePayment:b=>a(a=>({payments:a.payments.filter(a=>a.id!==b)})),updatePayment:(b,c)=>a(a=>({payments:a.payments.map(a=>a.id===b?{...a,...c}:a)})),replacePayment:(b,c)=>a(a=>({payments:a.payments.map(a=>a.id===b?c:a)})),setCreditNotes:b=>a({creditNotes:b}),addCreditNote:b=>a(a=>({creditNotes:[b,...a.creditNotes]})),removeCreditNote:b=>a(a=>({creditNotes:a.creditNotes.filter(a=>a.id!==b)})),updateCreditNote:(b,c)=>a(a=>({creditNotes:a.creditNotes.map(a=>a.id===b?{...a,...c}:a)})),replaceCreditNote:(b,c)=>a(a=>({creditNotes:a.creditNotes.map(a=>a.id===b?c:a)})),setSettings:b=>a({settings:b}),updateSettings:b=>a(a=>({settings:{...a.settings,...b}})),setViewFormat:(b,c)=>a(a=>({viewFormat:{...a.viewFormat,[b]:c}})),setUsers:b=>a({users:b}),addUser:b=>a(a=>({users:[...a.users,b]})),updateUser:(b,c)=>a(a=>({users:a.users.map(a=>a.id===b?{...a,...c}:a)})),removeUser:b=>a(a=>({users:a.users.map(a=>a.id===b?{...a,is_active:0,deletedAt:new Date().toISOString()}:a)})),setInvoiceDraft:b=>a(a=>({invoiceDraft:{...a.invoiceDraft,...b}})),clearInvoiceDraft:()=>a(a=>({invoiceDraft:{selectedClient:null,items:[{id:"1",description:"",quantity:1,unitPrice:0,total:0}],invoiceDate:new Date().toISOString().split("T")[0],discount:0,notes:a.settings.mentionsLegales||"",subject:""}})),setQuoteDraft:b=>a(a=>({quoteDraft:{...a.quoteDraft,...b}})),clearQuoteDraft:()=>{let b=new Date,c=new Date(b);return c.setDate(b.getDate()+30),a(a=>({quoteDraft:{selectedClient:null,items:[{id:"1",description:"",quantity:1,unitPrice:0,total:0}],quoteDate:b.toISOString().split("T")[0],discount:0,notes:a.settings.mentionsLegales||"",subject:"",validUntil:c.toISOString().split("T")[0],status:"EN_ATTENTE"}}))}}),{name:"facturier-storage",storage:(0,e.KU)(()=>sessionStorage),partialize:a=>({user:a.user,permissions:a.permissions,isAuthenticated:a.isAuthenticated,viewFormat:a.viewFormat})}))},13851:(a,b,c)=>{"use strict";c.d(b,{Providers:()=>k});var d=c(48249);c(67484);var e=c(8696),f=c(81595),g=c(31675),h=c(26284),i=c(90707);function j({error:a,resetErrorBoundary:b}){return(0,d.jsxs)("div",{className:"flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center",children:[(0,d.jsx)(g.A,{className:"w-16 h-16 text-destructive mb-4"}),(0,d.jsx)("h1",{className:"text-2xl font-bold text-slate-900 mb-2",children:"Une erreur inattendue est survenue"}),(0,d.jsx)("p",{className:"text-slate-500 mb-6 max-w-md",children:"Le composant applicatif a rencontr\xe9 un probl\xe8me. Veuillez rafra\xeechir la page ou retourner \xe0 l'accueil."}),(0,d.jsx)("div",{className:"bg-slate-100 p-4 rounded-md mb-6 w-full max-w-lg text-left overflow-auto text-sm text-slate-800",children:(0,d.jsx)("code",{children:a.message})}),(0,d.jsx)(h.$,{onClick:b,children:"R\xe9essayer"})]})}function k({children:a}){return(0,d.jsxs)(e.N,{attribute:"class",defaultTheme:"system",enableSystem:!0,disableTransitionOnChange:!1,children:[(0,d.jsx)(f.tH,{FallbackComponent:j,children:a}),(0,d.jsx)(i.l$,{position:"top-right",richColors:!0})]})}},18560:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23)),Promise.resolve().then(c.t.bind(c,15098,23)),Promise.resolve().then(c.t.bind(c,47644,23)),Promise.resolve().then(c.t.bind(c,33859,23)),Promise.resolve().then(c.t.bind(c,30129,23)),Promise.resolve().then(c.t.bind(c,98099,23)),Promise.resolve().then(c.t.bind(c,16237,23)),Promise.resolve().then(c.t.bind(c,98562,23)),Promise.resolve().then(c.t.bind(c,36675,23))},26284:(a,b,c)=>{"use strict";c.d(b,{$:()=>i,r:()=>h});var d=c(48249);c(67484);var e=c(43980),f=c(21654),g=c(33191);let h=(0,f.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary-hover",success:"bg-accent text-accent-foreground hover:bg-accent-hover",destructive:"bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",outline:"border bg-background shadow-xs hover:bg-primary-light hover:text-primary dark:bg-input/30 dark:border-input dark:hover:bg-input/50",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-primary-light hover:text-primary dark:hover:bg-primary/20",link:"text-primary underline-offset-4 hover:underline","primary-shadow":"bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20"},size:{default:"h-9 px-4 py-2 has-[>svg]:px-3",sm:"h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",lg:"h-10 rounded-md px-6 has-[>svg]:px-4",icon:"size-9","icon-sm":"size-8","icon-lg":"size-10"}},defaultVariants:{variant:"default",size:"default"}});function i({className:a,variant:b,size:c,asChild:f=!1,...j}){let k=f?e.DX:"button";return(0,d.jsx)(k,{"data-slot":"button",className:(0,g.cn)(h({variant:b,size:c,className:a})),...j})}},30850:(a,b,c)=>{"use strict";c.d(b,{Ht:()=>i,Sg:()=>g});var d=c(36042);function e(){let a=process.env.SESSION_SECRET;if(a&&a.length>=32)return a;if("true"===process.env.VITEST){if("trop-court"===a)throw Error("[SECURITY] SESSION_SECRET environment variable is missing or too short.");return"facturier-gabon-2026-fallback-dev-secret-key-32chars!!"}throw Error("[SECURITY] SESSION_SECRET environment variable is missing or too short.")}function f(a){return new TextEncoder().encode(a)}async function g(a){let b=e(),c=await crypto.subtle.importKey("raw",f(b),{name:"HMAC",hash:"SHA-256"},!1,["sign"]),d=btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.sign("HMAC",c,f(a)))));return`${a}.${d}`}async function h(a,b,c){try{let d=c||e(),g=await crypto.subtle.importKey("raw",f(d),{name:"HMAC",hash:"SHA-256"},!1,["verify"]);return await crypto.subtle.verify("HMAC",g,function(a){if("u">typeof Buffer)return Uint8Array.from(Buffer.from(a,"base64"));let b=atob(a),c=new Uint8Array(b.length);for(let a=0;a<b.length;a++)c[a]=b.charCodeAt(a);return c}(b),f(a))}catch(a){return!1}}async function i(a,b){try{let c=a;if(!c){let a=await (0,d.UL)();c=a.get("auth_session")?.value}if(!c)return null;let[e,f]=c.split(".");if(!e||!f||!await h(e,f,b))return null;let g=JSON.parse(atob(e));if(!g||"number"!=typeof g.exp||g.exp<Date.now())return null;return g}catch(a){return null}}},32056:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>h,metadata:()=>g});var d=c(5735),e=c(73593),f=c(49970);c(82704);let g={title:"Facturier — Gestion & Facturation"};function h({children:a}){return(0,d.jsx)("html",{lang:"fr",suppressHydrationWarning:!0,className:"bg-background",children:(0,d.jsx)("body",{className:"font-sans antialiased bg-background text-foreground select-none",children:(0,d.jsx)(f.AppErrorBoundary,{children:(0,d.jsx)(e.Providers,{children:a})})})})}},33191:(a,b,c)=>{"use strict";c.d(b,{Yq:()=>h,cn:()=>f,vv:()=>g});var d=c(99314),e=c(96862);function f(...a){return(0,e.QP)((0,d.$)(a))}function g(a){return new Intl.NumberFormat("fr-FR",{style:"decimal",minimumFractionDigits:0,maximumFractionDigits:0}).format(Math.round(a)).replace(/\u00a0/g," ")+" FCFA"}function h(a){if(!a)return"";if(/^\d{4}-\d{2}-\d{2}$/.test(a.trim())){let[b,c,d]=a.trim().split("-");return`${d}/${c}/${b}`}let b=new Date(a);return isNaN(b.getTime())?a:new Intl.DateTimeFormat("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"}).format(b)}},42937:(a,b,c)=>{"use strict";c.d(b,{A:()=>i});var d=c(89353),e=c(55511),f=c.n(e);let g=d.A.prepare("SELECT name, username FROM users WHERE id = ?"),h=d.A.prepare(`
    INSERT INTO audit_logs (id, userId, userName, action, entityType, entityId, details)
    VALUES (?, ?, ?, ?, ?, ?, ?)
`);function i(a,b,c,d,e,i){try{let j=i||null;if(e&&!j)try{let a=g.get(e);a&&(j=a.name||a.username||null)}catch(a){}let k=j||e||"System";h.run(f().randomUUID(),e||null,k,a,b,c,d)}catch(a){console.error("Failed to log audit:",a)}}},43852:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23))},46585:(a,b,c)=>{"use strict";c.d(b,{EP:()=>p,TW:()=>s,X5:()=>n,bF:()=>e,dP:()=>k,dh:()=>l,jK:()=>i,lk:()=>u,ms:()=>j,rJ:()=>v,s:()=>m,s2:()=>q,vw:()=>t,wl:()=>f,z$:()=>o});var d=c(95966);let e=d.Ik({name:d.Yj().min(2,"Le nom doit contenir au moins 2 caract\xe8res").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),email:d.Yj().email("Adresse email invalide").max(255,"L'email ne peut pas d\xe9passer 255 caract\xe8res"),phone:d.Yj().max(255,"Le num\xe9ro de t\xe9l\xe9phone ne peut pas d\xe9passer 255 caract\xe8res").optional().refine(a=>!a||a.length>=6,"Num\xe9ro de t\xe9l\xe9phone invalide"),address:d.Yj().max(1e3,"L'adresse ne peut pas d\xe9passer 1000 caract\xe8res").optional().refine(a=>!a||a.length>=5,"L'adresse doit contenir au moins 5 caract\xe8res")}),f=d.Ik({name:d.Yj().min(2,"Le nom doit contenir au moins 2 caract\xe8res").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),email:d.Yj().email("Adresse email invalide").max(255,"L'email ne peut pas d\xe9passer 255 caract\xe8res"),phone:d.Yj().max(255,"Le num\xe9ro de t\xe9l\xe9phone ne peut pas d\xe9passer 255 caract\xe8res").optional().refine(a=>!a||a.length>=6,"Num\xe9ro de t\xe9l\xe9phone invalide"),address:d.Yj().max(1e3,"L'adresse ne peut pas d\xe9passer 1000 caract\xe8res").optional().refine(a=>!a||a.length>=5,"L'adresse doit contenir au moins 5 caract\xe8res")}),g=d.Ik({id:d.Yj().max(255).optional(),description:d.Yj().min(1,"La description est requise").max(1e3,"La description ne peut pas d\xe9passer 1000 caract\xe8res"),quantity:d.ai().min(.01,"La quantit\xe9 doit \xeatre sup\xe9rieure \xe0 0"),unitPrice:d.ai().int("Le prix unitaire doit \xeatre un entier (XAF, pas de d\xe9cimales)").min(0,"Le prix unitaire ne peut pas \xeatre n\xe9gatif")}),h=d.Ik({description:d.Yj().min(1,"La description est requise").max(1e3,"La description ne peut pas d\xe9passer 1000 caract\xe8res"),quantity:d.ai().min(.01,"La quantit\xe9 doit \xeatre sup\xe9rieure \xe0 0"),unitPrice:d.ai().int("Le prix unitaire doit \xeatre un entier (XAF, pas de d\xe9cimales)").min(0,"Le prix unitaire ne peut pas \xeatre n\xe9gatif")}),i=d.Ik({clientId:d.Yj().min(1,"Client requis").max(255),clientName:d.Yj().max(255,"Le nom du client ne peut pas d\xe9passer 255 caract\xe8res"),clientEmail:d.Yj().max(255,"L'email du client ne peut pas d\xe9passer 255 caract\xe8res"),discount:d.ai().int("La remise doit \xeatre un entier en XAF").min(0).default(0),date:d.Yj().regex(/^\d{4}-\d{2}-\d{2}$/,"Format de date invalide"),items:d.YO(g).min(1,"Au moins un article est requis"),notes:d.Yj().max(5e3,"Les notes ne peuvent pas d\xe9passer 5000 caract\xe8res").optional(),subject:d.Yj().max(255,"L'objet ne peut pas d\xe9passer 255 caract\xe8res").optional(),quoteId:d.Yj().max(255).optional()}),j=d.Ik({clientId:d.Yj().min(1,"Client requis").max(255),clientName:d.Yj().max(255,"Le nom du client ne peut pas d\xe9passer 255 caract\xe8res"),clientEmail:d.Yj().max(255,"L'email du client ne peut pas d\xe9passer 255 caract\xe8res"),discount:d.ai().int("La remise doit \xeatre un entier en XAF").min(0).default(0),date:d.Yj().regex(/^\d{4}-\d{2}-\d{2}$/,"Format de date invalide"),items:d.YO(h).min(1,"Au moins un article est requis"),notes:d.Yj().max(5e3,"Les notes ne peuvent pas d\xe9passer 5000 caract\xe8res").optional(),subject:d.Yj().max(255,"L'objet ne peut pas d\xe9passer 255 caract\xe8res").optional(),validUntil:d.Yj().regex(/^\d{4}-\d{2}-\d{2}$/,"Format de date invalide").optional()}),k=d.Ik({companyName:d.Yj({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1,"Le nom de l'entreprise est requis").max(255,"Le nom de l'entreprise ne peut pas d\xe9passer 255 caract\xe8res"),legalForm:d.Yj({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1,"La forme juridique est requise").max(255,"La forme juridique ne peut pas d\xe9passer 255 caract\xe8res"),nif:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le NIF ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),rccm:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le RCCM ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),address:d.Yj({invalid_type_error:"Format invalide"}).max(1e3,"L'adresse ne peut pas d\xe9passer 1000 caract\xe8res").nullable().optional(),email:d.KC([d.eu(""),d.Yj().email("Adresse email invalide").max(255,"L'email ne peut pas d\xe9passer 255 caract\xe8res")]).optional().nullable(),phone:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le t\xe9l\xe9phone ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),bankName:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le nom de la banque ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),bankAgency:d.Yj({invalid_type_error:"Format invalide"}).max(255,"L'agence bancaire ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),accountNumber:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le num\xe9ro de compte ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),swiftCode:d.Yj({invalid_type_error:"Format invalide"}).max(255,"Le code SWIFT ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),iban:d.Yj({invalid_type_error:"Format invalide"}).max(255,"L'IBAN ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional(),tvaRate:d.ai({required_error:"La TVA est requise",invalid_type_error:"La TVA est requise"}).min(0),tpsRate:d.ai({invalid_type_error:"Format invalide"}).min(0).nullable().optional(),cssRate:d.ai({required_error:"La CSS est requise",invalid_type_error:"La CSS est requise"}).min(0),sessionTimeout:d.ai({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1),invoicePrefix:d.Yj({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1,"Le pr\xe9fixe de facture est requis").max(255,"Le pr\xe9fixe de facture ne peut pas d\xe9passer 255 caract\xe8res"),quotePrefix:d.Yj({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1,"Le pr\xe9fixe de devis est requis").max(255,"Le pr\xe9fixe de devis ne peut pas d\xe9passer 255 caract\xe8res"),companyCode:d.Yj({required_error:"Ce champ est requis",invalid_type_error:"Ce champ est requis"}).min(1,"Le code de l'entreprise est requis").max(255,"Le code de l'entreprise ne peut pas d\xe9passer 255 caract\xe8res"),mentionsLegales:d.Yj({invalid_type_error:"Format invalide"}).max(5e3,"Les mentions l\xe9gales ne peuvent pas d\xe9passer 5000 caract\xe8res").nullable().optional(),logo:d.Yj({invalid_type_error:"Format invalide"}).max(2097152,"Le logo est trop volumineux (max 2 Mo encod\xe9)").nullable().optional()}),l=d.Ik({name:d.Yj().min(1,"Le nom est requis").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),description:d.Yj().max(5e3,"La description ne peut pas d\xe9passer 5000 caract\xe8res").optional(),category:d.Yj().max(255,"La cat\xe9gorie ne peut pas d\xe9passer 255 caract\xe8res").optional(),unitPrice:d.ai().int("Le prix doit \xeatre un entier en XAF (pas de d\xe9cimales)").min(0,"Le prix ne peut pas \xeatre n\xe9gatif")}),m=d.Ik({name:d.Yj().min(1,"Le nom est requis").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),description:d.Yj().max(5e3,"La description ne peut pas d\xe9passer 5000 caract\xe8res").optional(),category:d.Yj().max(255,"La cat\xe9gorie ne peut pas d\xe9passer 255 caract\xe8res").optional(),unitPrice:d.ai().int("Le prix doit \xeatre un entier en XAF (pas de d\xe9cimales)").min(0,"Le prix ne peut pas \xeatre n\xe9gatif")}),n=d.Ik({username:d.Yj().min(1,"L'identifiant est requis").max(255,"L'identifiant ne peut pas d\xe9passer 255 caract\xe8res"),password:d.Yj().min(1,"Le mot de passe est requis").max(255,"Le mot de passe ne peut pas d\xe9passer 255 caract\xe8res")}),o=d.Ik({name:d.Yj({required_error:"Le nom complet est requis",invalid_type_error:"Le nom doit \xeatre une cha\xeene de caract\xe8res"}).min(2,"Le nom doit contenir au moins 2 caract\xe8res").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),email:d.Yj({required_error:"L'adresse email est requise",invalid_type_error:"L'email doit \xeatre une cha\xeene de caract\xe8res"}).email("Adresse email invalide").max(255,"L'email ne peut pas d\xe9passer 255 caract\xe8res"),username:d.Yj({required_error:"L'identifiant est requis",invalid_type_error:"L'identifiant doit \xeatre une cha\xeene de caract\xe8res"}).min(1,"L'identifiant est requis").max(255,"L'identifiant ne peut pas d\xe9passer 255 caract\xe8res").optional().nullable(),role:d.k5(["admin","user"],{required_error:"Le r\xf4le est requis",invalid_type_error:"R\xf4le invalide ('admin' ou 'user')"}),password:d.Yj({required_error:"Le mot de passe est requis",invalid_type_error:"Le mot de passe doit \xeatre une cha\xeene de caract\xe8res"}).min(8,"Le mot de passe doit contenir au moins 8 caract\xe8res").max(255,"Le mot de passe ne peut pas d\xe9passer 255 caract\xe8res").regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,"Le mot de passe doit contenir au moins une majuscule, une minuscule et un chiffre"),phone:d.Yj({invalid_type_error:"Le t\xe9l\xe9phone doit \xeatre une cha\xeene de caract\xe8res"}).max(255,"Le t\xe9l\xe9phone ne peut pas d\xe9passer 255 caract\xe8res").optional().nullable().or(d.eu("")),force_password_change:d.zM().default(!0),is_active:d.zM().default(!0)}),p=d.Ik({name:d.Yj({required_error:"Le nom complet est requis",invalid_type_error:"Le nom doit \xeatre une cha\xeene de caract\xe8res"}).min(2,"Le nom doit contenir au moins 2 caract\xe8res").max(255,"Le nom ne peut pas d\xe9passer 255 caract\xe8res"),email:d.Yj({invalid_type_error:"L'email doit \xeatre une cha\xeene de caract\xe8res"}).email("Adresse email invalide").max(255,"L'email ne peut pas d\xe9passer 255 caract\xe8res").optional().nullable().or(d.eu("")),role:d.k5(["admin","user"],{required_error:"Le r\xf4le est requis",invalid_type_error:"R\xf4le invalide ('admin' ou 'user')"}),password:d.Yj({invalid_type_error:"Le mot de passe doit \xeatre une cha\xeene de caract\xe8res"}).min(8,"Le mot de passe doit contenir au moins 8 caract\xe8res").max(255,"Le mot de passe ne peut pas d\xe9passer 255 caract\xe8res").regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,"Le mot de passe doit contenir au moins une majuscule, une minuscule et un chiffre").optional().nullable().or(d.eu("")),phone:d.Yj({invalid_type_error:"Le t\xe9l\xe9phone doit \xeatre une cha\xeene de caract\xe8res"}).max(255,"Le t\xe9l\xe9phone ne peut pas d\xe9passer 255 caract\xe8res").optional().nullable().or(d.eu("")),force_password_change:d.zM().optional().nullable(),is_active:d.zM().optional().nullable()}),q=d.Ik({invoiceId:d.Yj().min(1,"L'ID de la facture est requis").max(255),amount:d.ai().int("Le montant doit \xeatre un entier en XAF (pas de d\xe9cimales)").min(1,"Le montant doit \xeatre sup\xe9rieur \xe0 0"),paymentMethod:d.Yj().min(1,"La m\xe9thode de paiement est requise").max(255,"La m\xe9thode de paiement ne peut pas d\xe9passer 255 caract\xe8res"),date:d.Yj().regex(/^\d{4}-\d{2}-\d{2}$/,"Format de date invalide (YYYY-MM-DD)"),reference:d.Yj().max(255,"La r\xe9f\xe9rence ne peut pas d\xe9passer 255 caract\xe8res").nullable().optional()}),r=d.Ik({description:d.Yj().min(1,"La description est requise").max(1e3,"La description ne peut pas d\xe9passer 1000 caract\xe8res"),quantity:d.ai().min(.01,"La quantit\xe9 doit \xeatre sup\xe9rieure \xe0 0"),unitPrice:d.ai().min(0,"Le prix unitaire ne peut pas \xeatre n\xe9gatif")}),s=d.Ik({invoiceId:d.Yj().min(1,"L'ID de la facture est requis").max(255),reason:d.Yj().min(1,"La raison est requise").max(1e3,"La raison ne peut pas d\xe9passer 1000 caract\xe8res"),items:d.YO(r).min(1,"Au moins un article est requis")}),t=d.Ik({range:d.k5(["month","quarter","year"]).optional()}),u=d.Ik({quoteId:d.Yj().min(1,"L'ID du devis est requis").max(255)});d.Ik({quoteId:d.Yj().min(1,"L'ID du devis est requis").max(255)});let v=d.Ik({name:d.Yj().min(1,"Le nom complet est requis").max(255),email:d.Yj().email("Adresse email invalide").max(255),password:d.Yj().min(6,"Le mot de passe doit contenir au moins 6 caract\xe8res").max(255),phone:d.Yj().max(255).optional(),companyName:d.Yj().min(1,"Le nom de l'entreprise est requis").max(255),nif:d.Yj().max(255).optional(),rccm:d.Yj().max(255).optional(),address:d.Yj().max(1e3).optional(),companyPhone:d.Yj().max(255).optional(),companyEmail:d.Yj().email("Email d'entreprise invalide").optional().or(d.eu(""))})},49970:(a,b,c)=>{"use strict";c.d(b,{AppErrorBoundary:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call AppErrorBoundary() from the server but AppErrorBoundary is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\LENOVO\\Downloads\\fintech-invoicing-app\\components\\error-boundary.tsx","AppErrorBoundary")},52928:(a,b,c)=>{Promise.resolve().then(c.bind(c,62148)),Promise.resolve().then(c.bind(c,13851))},58443:(a,b,c)=>{"use strict";c.d(b,{G:()=>e});var d=c(89353);let e={findAllActive:()=>d.A.prepare("SELECT * FROM users WHERE deletedAt IS NULL").all(),findByUsername:a=>d.A.prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND deletedAt IS NULL").get(a,a),findById:a=>d.A.prepare("SELECT * FROM users WHERE id = ? AND deletedAt IS NULL").get(a),create(a){d.A.prepare(`
      INSERT INTO users (id, name, email, username, password, role, is_active, created_by, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(a.id,a.name,a.email,a.username,a.password,a.role,a.is_active,a.created_by,a.phone||null)},update(a,b){let c=[],e=[];Object.entries(b).forEach(([a,b])=>{c.push(`${a} = ?`),e.push(b)}),0!==c.length&&(e.push(a),d.A.prepare(`UPDATE users SET ${c.join(", ")} WHERE id = ?`).run(...e))},updateLastLogin(a){d.A.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?").run(a)},softDelete(a){d.A.prepare("UPDATE users SET deletedAt = datetime('now') WHERE id = ?").run(a)},checkEmailExists:a=>!!d.A.prepare("SELECT id FROM users WHERE email = ? AND deletedAt IS NULL").get(a),checkUsernameExists:a=>!!d.A.prepare("SELECT id FROM users WHERE username = ? AND deletedAt IS NULL").get(a)}},62148:(a,b,c)=>{"use strict";c.d(b,{AppErrorBoundary:()=>j});var d=c(48249),e=c(67484),f=c(31675),g=c(69924),h=c(72419),i=c(44218);class j extends e.Component{constructor(a){super(a),this.handleReload=()=>{this.setState({hasError:!1,error:null,errorInfo:null,showDetails:!1}),window.location.reload()},this.toggleDetails=()=>{this.setState(a=>({showDetails:!a.showDetails}))},this.state={hasError:!1,error:null,errorInfo:null,showDetails:!1}}static getDerivedStateFromError(a){return{hasError:!0,error:a}}componentDidCatch(a,b){this.setState({errorInfo:b}),console.error("[AppErrorBoundary] Crash captur\xe9:",a.message,b.componentStack)}render(){return this.state.hasError?(0,d.jsx)("div",{className:"min-h-screen bg-background flex items-center justify-center p-8",children:(0,d.jsxs)("div",{className:"max-w-lg w-full",children:[(0,d.jsx)("div",{className:"w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-6",children:(0,d.jsx)(f.A,{className:"w-8 h-8 text-destructive"})}),(0,d.jsx)("h1",{className:"text-xl font-semibold text-foreground text-center tracking-tight mb-2",children:"Une erreur inattendue s'est produite"}),(0,d.jsx)("p",{className:"text-sm text-muted-foreground text-center mb-8 leading-relaxed",children:this.props.fallbackMessage||"L'application a rencontr\xe9 un probl\xe8me. Vos donn\xe9es sont en s\xe9curit\xe9 — la base de donn\xe9es n'a pas \xe9t\xe9 affect\xe9e."}),this.state.error&&(0,d.jsx)("div",{className:"bg-destructive/5 border border-destructive/20 rounded-xl p-4 mb-6",children:(0,d.jsxs)("p",{className:"text-xs font-mono text-destructive break-all",children:[this.state.error.name,": ",this.state.error.message]})}),(0,d.jsx)("div",{className:"flex gap-3 mb-4",children:(0,d.jsxs)("button",{onClick:this.handleReload,className:"flex-1 flex items-center justify-center gap-2 h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-colors",children:[(0,d.jsx)(g.A,{className:"w-4 h-4"}),"Recharger l'application"]})}),this.state.errorInfo&&(0,d.jsxs)("div",{children:[(0,d.jsxs)("button",{onClick:this.toggleDetails,className:"w-full flex items-center justify-between p-3 rounded-xl text-xs text-muted-foreground hover:bg-secondary transition-colors",children:[(0,d.jsx)("span",{className:"font-bold uppercase tracking-widest",children:"D\xe9tails techniques"}),this.state.showDetails?(0,d.jsx)(h.A,{className:"w-4 h-4"}):(0,d.jsx)(i.A,{className:"w-4 h-4"})]}),this.state.showDetails&&(0,d.jsx)("div",{className:"mt-2 bg-secondary rounded-xl p-4 overflow-auto max-h-48",children:(0,d.jsx)("pre",{className:"text-[10px] font-mono text-muted-foreground whitespace-pre-wrap break-all",children:this.state.errorInfo.componentStack})})]})]})}):this.props.children}}},73593:(a,b,c)=>{"use strict";c.d(b,{Providers:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\LENOVO\\Downloads\\fintech-invoicing-app\\components\\providers.tsx","Providers")},78335:()=>{},80300:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23))},82112:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23)),Promise.resolve().then(c.t.bind(c,60440,23)),Promise.resolve().then(c.t.bind(c,84342,23)),Promise.resolve().then(c.t.bind(c,82265,23)),Promise.resolve().then(c.t.bind(c,56207,23)),Promise.resolve().then(c.t.bind(c,35421,23)),Promise.resolve().then(c.t.bind(c,61335,23)),Promise.resolve().then(c.t.bind(c,70664,23)),Promise.resolve().then(c.bind(c,74661))},82432:(a,b,c)=>{Promise.resolve().then(c.bind(c,49970)),Promise.resolve().then(c.bind(c,73593))},82704:()=>{},89353:(a,b,c)=>{"use strict";let d;c.d(b,{A:()=>r});var e=c(87550),f=c.n(e),g=c(33873),h=c.n(g),i=c(29021),j=c.n(i),k=c(21820),l=c.n(k);let m=globalThis,n=function(){let a=process.env.TEST_DB_PATH;if(a){let b=h().resolve(a);return console.log(`[db] Niveau 0 (Test/E2E) : ${b}`),b}let b=process.env.DB_FILE_NAME||"database.sqlite",c=process.env.ELECTRON_USERDATA_PATH;if(c){let a=h().join(c,"data");try{j().existsSync(a)||j().mkdirSync(a,{recursive:!0});let c=h().resolve(h().join(a,b));return console.log(`[db] Niveau 1 (Electron userData) : ${c}`),c}catch(a){console.error("[db] NIVEAU 1 \xc9CHOU\xc9 — impossible d'\xe9crire dans ELECTRON_USERDATA_PATH :",a)}}let d=h().join(l().homedir(),".facturier-invoicing","data");try{j().existsSync(d)||j().mkdirSync(d,{recursive:!0})}catch(a){console.error("[db] NIVEAU 3 \xc9CHOU\xc9 — impossible de cr\xe9er le r\xe9pertoire homedir :",a)}let e=h().resolve(h().join(d,b));return console.warn(`[db] Niveau 3 (Fallback homedir) : ${e}`),e}();try{d=m.db||new(f())(n,{timeout:5e3}),m.db||(m.db=d,m.db_ready=!1)}catch(a){throw process.stderr.write(`[db] FATAL: Impossible d'ouvrir la base de donn\xe9es : ${n}
`),process.stderr.write(`[db] FATAL: ${a?.message||a}
`),process.stderr.write(`[db] FATAL: V\xe9rifiez l'ABI de better_sqlite3.node et les droits d'acc\xe8s au r\xe9pertoire.
`),a}d.pragma("foreign_keys = ON"),d.pragma("journal_mode = WAL"),d.pragma("synchronous = NORMAL");let o=()=>{if(!m.isClosing){m.isClosing=!0;try{if(d&&d.open){try{d.pragma("wal_checkpoint(TRUNCATE)")}catch(a){}d.close(),console.log("[db] Base de donn\xe9es SQLite ferm\xe9e proprement (WAL Checkpoint & Close).")}}catch(a){console.error("[db] Erreur lors de la fermeture de la base de donn\xe9es:",a)}}};m.isClosing||(process.on("exit",o),process.on("beforeExit",o),process.on("SIGINT",()=>{o(),process.exit(0)}),process.on("SIGTERM",()=>{o(),process.exit(0)}),process.on("SIGHUP",()=>{o(),process.exit(0)}),process.on("SIGBREAK",()=>{o(),process.exit(0)}));let p=m.statementCache||new Map;function q(a){let b=p.get(a);return b||(b=d.prepare(a),p.set(a,b)),b}m.statementCache=p;try{d.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    companyName TEXT,
    legalForm TEXT,
    nif TEXT,
    rccm TEXT,
    address TEXT,
    email TEXT,
    phone TEXT,
    bankName TEXT,
    bankAgency TEXT,
    accountNumber TEXT,
    swiftCode TEXT,
    iban TEXT,
    tvaRate REAL,
    tpsRate REAL DEFAULT 9.5,
    cssRate REAL,
    sessionTimeout INTEGER,
    invoicePrefix TEXT,
    quotePrefix TEXT,
    companyCode TEXT,
    mentionsLegales TEXT,
    logo TEXT
  );

  CREATE TABLE IF NOT EXISTS clients (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    address TEXT,
    status TEXT DEFAULT 'active',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT
  );

  CREATE TABLE IF NOT EXISTS quotes (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    clientId TEXT NOT NULL,
    clientName TEXT,
    clientEmail TEXT,
    date TEXT NOT NULL,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'EN_ATTENTE',
    notes TEXT,
    subject TEXT,
    validUntil TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (clientId) REFERENCES clients(id)
  );

  CREATE TABLE IF NOT EXISTS quote_items (
    id TEXT PRIMARY KEY,
    quoteId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (quoteId) REFERENCES quotes(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    quoteId TEXT,
    clientId TEXT NOT NULL,
    clientName TEXT,
    clientEmail TEXT,
    date TEXT NOT NULL,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'UNPAID',
    notes TEXT,
    subject TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (clientId) REFERENCES clients(id),
    FOREIGN KEY (quoteId) REFERENCES quotes(id)
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    amount REAL NOT NULL,
    paymentMethod TEXT NOT NULL,
    date TEXT NOT NULL,
    reference TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS sequences (
    name TEXT PRIMARY KEY,
    current_value INTEGER DEFAULT 0,
    last_year INTEGER


  );

  INSERT OR IGNORE INTO sequences (name, current_value, last_year) VALUES ('quote', 0, strftime('%Y', 'now'));
  INSERT OR IGNORE INTO sequences (name, current_value, last_year) VALUES ('invoice', 0, strftime('%Y', 'now'));

  CREATE TABLE IF NOT EXISTS services (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    unitPrice REAL DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    deletedAt DATETIME,
    created_by TEXT
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT CHECK(role IN ('admin', 'user')) NOT NULL DEFAULT 'user',
    is_active INTEGER NOT NULL DEFAULT 1,
    force_password_change INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME,
    created_by TEXT,
    phone TEXT,
    deletedAt DATETIME
  );

  CREATE TABLE IF NOT EXISTS credit_notes (
    id TEXT PRIMARY KEY,
    number TEXT UNIQUE NOT NULL,
    invoiceId TEXT NOT NULL,
    clientId TEXT NOT NULL,
    clientName TEXT,
    date TEXT NOT NULL,
    reason TEXT,
    subtotal REAL DEFAULT 0,
    taxBase REAL DEFAULT 0,
    tpsAmount REAL DEFAULT 0,
    tvaAmount REAL DEFAULT 0,
    cssAmount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'open',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    deletedAt DATETIME,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id),
    FOREIGN KEY (clientId) REFERENCES clients(id)
  );

  CREATE TABLE IF NOT EXISTS credit_note_items (
    id TEXT PRIMARY KEY,
    creditNoteId TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL,
    unitPrice REAL NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (creditNoteId) REFERENCES credit_notes(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    userId TEXT,
    userName TEXT,
    action TEXT NOT NULL,
    entityType TEXT NOT NULL,
    entityId TEXT,
    details TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),m.db.pragma("journal_mode = WAL"),process.env.NEXT_BUILD||(m.db_ready=!0,process.stdout.write(`[db] Sch\xe9ma initialis\xe9 avec succ\xe8s : ${n}
`))}catch(a){throw process.stderr.write(`[db] FATAL: \xc9chec de l'initialisation du sch\xe9ma sur : ${n}
`),process.stderr.write(`[db] FATAL: ${a?.message||a}
`),a}try{let a=d.prepare("PRAGMA table_info(users)").all();a.some(a=>"is_active"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1").run(),a.some(a=>"force_password_change"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN force_password_change INTEGER NOT NULL DEFAULT 0").run(),a.some(a=>"last_login_at"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN last_login_at DATETIME").run(),a.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN created_by TEXT").run(),a.some(a=>"email"===a.name)||(d.prepare("ALTER TABLE users ADD COLUMN email TEXT").run(),d.prepare("UPDATE users SET email = username WHERE email IS NULL").run()),a.some(a=>"created_at"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP").run(),a.some(a=>"phone"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN phone TEXT").run(),a.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE users ADD COLUMN deletedAt DATETIME").run()}catch(a){console.error("Migration error on users table:",a)}try{let a=d.prepare("PRAGMA table_info(quotes)").all();a.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN created_by TEXT").run(),a.some(a=>"subject"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN subject TEXT").run(),a.some(a=>"validUntil"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN validUntil TEXT").run();let b=d.prepare("PRAGMA table_info(invoices)").all();b.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN created_by TEXT").run(),b.some(a=>"subject"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN subject TEXT").run();let c=d.prepare("PRAGMA table_info(services)").all();c.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE services ADD COLUMN created_by TEXT").run(),b.some(a=>"dueDate"===a.name)||(d.prepare("ALTER TABLE invoices ADD COLUMN dueDate TEXT").run(),d.prepare("UPDATE invoices SET dueDate = date(date, '+30 days') WHERE dueDate IS NULL").run()),d.prepare("UPDATE invoices SET status = 'UNPAID' WHERE status IN ('pending', 'sent', 'open')").run(),d.prepare("UPDATE invoices SET status = 'PAID' WHERE status = 'paid'").run(),d.prepare("UPDATE invoices SET status = 'PARTIALLY_PAID' WHERE status IN ('partially_paid', 'partial')").run(),d.prepare("PRAGMA table_info(settings)").all().some(a=>"tpsRate"===a.name)||d.prepare("ALTER TABLE settings ADD COLUMN tpsRate REAL DEFAULT 9.5").run(),a.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE quotes ADD COLUMN tpsAmount REAL DEFAULT 0").run(),b.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE invoices ADD COLUMN tpsAmount REAL DEFAULT 0").run();let e=d.prepare("PRAGMA table_info(credit_notes)").all();e.some(a=>"tpsAmount"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN tpsAmount REAL DEFAULT 0").run(),e.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN created_by TEXT").run();let f=d.prepare("PRAGMA table_info(clients)").all();f.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE clients ADD COLUMN deletedAt DATETIME").run(),f.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE clients ADD COLUMN created_by TEXT").run(),c.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE services ADD COLUMN deletedAt DATETIME").run(),e.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE credit_notes ADD COLUMN deletedAt DATETIME").run();let g=d.prepare("PRAGMA table_info(payments)").all();g.some(a=>"deletedAt"===a.name)||d.prepare("ALTER TABLE payments ADD COLUMN deletedAt DATETIME").run(),g.some(a=>"created_by"===a.name)||d.prepare("ALTER TABLE payments ADD COLUMN created_by TEXT").run()}catch(a){console.error("Migration error:",a)}d.exec(`
  CREATE INDEX IF NOT EXISTS idx_clients_deletedAt ON clients(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_deletedAt ON quotes(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_clientId ON quotes(clientId);
  CREATE INDEX IF NOT EXISTS idx_invoices_deletedAt ON invoices(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_clientId ON invoices(clientId);
  CREATE INDEX IF NOT EXISTS idx_invoices_quoteId ON invoices(quoteId);
  CREATE INDEX IF NOT EXISTS idx_payments_deletedAt ON payments(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_payments_invoiceId ON payments(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_payments_created_by ON payments(created_by);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_deletedAt ON credit_notes(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_invoiceId ON credit_notes(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_credit_notes_clientId ON credit_notes(clientId);
  CREATE INDEX IF NOT EXISTS idx_services_deletedAt ON services(deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quote_items_quoteId ON quote_items(quoteId);
  CREATE INDEX IF NOT EXISTS idx_invoice_items_invoiceId ON invoice_items(invoiceId);
  CREATE INDEX IF NOT EXISTS idx_credit_note_items_creditNoteId ON credit_note_items(creditNoteId);
  
  -- Users optimizations
  CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);
  CREATE INDEX IF NOT EXISTS idx_users_deletedAt ON users(deletedAt);

  -- High Performance Indices (Phase 2 Architect)
  CREATE INDEX IF NOT EXISTS idx_invoices_status_deleted ON invoices(status, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_created_by ON invoices(created_by);
  CREATE INDEX IF NOT EXISTS idx_quotes_status_deleted ON quotes(status, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_quotes_created_by ON quotes(created_by);
  CREATE INDEX IF NOT EXISTS idx_payments_invoice_deleted ON payments(invoiceId, deletedAt);
  CREATE INDEX IF NOT EXISTS idx_invoices_dashboard ON invoices(deletedAt, status, created_by);
  CREATE INDEX IF NOT EXISTS idx_quotes_dashboard ON quotes(deletedAt, status, created_by);
  CREATE INDEX IF NOT EXISTS idx_clients_deleted ON clients(deletedAt);
`);try{d.prepare("UPDATE payments SET created_by = (SELECT created_by FROM invoices WHERE id = payments.invoiceId) WHERE created_by IS NULL").run();let a=d.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();a?.id&&(d.prepare("UPDATE clients SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE services SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE quotes SET created_by = ? WHERE created_by IS NULL").run(a.id),d.prepare("UPDATE invoices SET created_by = ? WHERE created_by IS NULL").run(a.id))}catch(a){console.error("Backfilling & Orphans Cleanup error:",a)}let r=new Proxy(d,{get(a,b,c){if("prepare"===b)return q;let d=Reflect.get(a,b,c);return"function"==typeof d?d.bind(a):d}})},96487:()=>{}};